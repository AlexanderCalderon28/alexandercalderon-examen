package com.example.service_vehiculos.service;

import com.example.service_vehiculos.exception.VehiculoNotFoundException;
import com.example.service_vehiculos.model.Vehiculo;
import com.example.service_vehiculos.repository.VehiculoRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class VehiculoServiceTest {

    @Mock
    private VehiculoRepository vehiculoRepository;

    @InjectMocks
    private VehiculoService vehiculoService;

    @Test
    @DisplayName("Listar todos los vehículos retorna lista correcta")
    void listarTodo_retornaLista() {
        Vehiculo v = new Vehiculo();
        v.setIdVehiculo(1L);
        v.setPatente("ABCD12");
        v.setActivo(true);

        when(vehiculoRepository.findAll()).thenReturn(List.of(v));

        List<Vehiculo> resultado = vehiculoService.listarTodo();

        assertFalse(resultado.isEmpty());
        assertEquals("ABCD12", resultado.get(0).getPatente());
        verify(vehiculoRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Buscar vehículo por id inexistente retorna vacío")
    void buscarPorId_noExiste_retornaVacio() {
        when(vehiculoRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Vehiculo> resultado = vehiculoService.buscarPorId(99L);

        assertTrue(resultado.isEmpty());
    }

    @Test
    @DisplayName("Crear vehículo con patente duplicada lanza excepción")
    void guardar_patenteDuplicada_lanzaExcepcion() {
        Vehiculo existente = new Vehiculo();
        existente.setPatente("ABCD12");

        when(vehiculoRepository.findByPatente("ABCD12")).thenReturn(Optional.of(existente));

        com.example.service_vehiculos.dto.VehiculoDTO dto = new com.example.service_vehiculos.dto.VehiculoDTO();
        dto.setPatente("ABCD12");

        assertThrows(IllegalArgumentException.class, () -> vehiculoService.guardar(dto));
    }

    @Test
    @DisplayName("Eliminar vehículo inexistente lanza excepción")
    void eliminar_noExiste_lanzaExcepcion() {
        when(vehiculoRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(VehiculoNotFoundException.class, () -> vehiculoService.eliminar(99L));
    }
}
