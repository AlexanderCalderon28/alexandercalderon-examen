package com.example.service_vehiculos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceVehiculosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceVehiculosApplication.class, args);
	}

}