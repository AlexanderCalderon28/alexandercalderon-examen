package com.example.service_vehiculos.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service_vehiculos.dto.VehiculoDTO;
import com.example.service_vehiculos.exception.VehiculoNotFoundException;
import com.example.service_vehiculos.model.Vehiculo;
import com.example.service_vehiculos.repository.VehiculoRepository;

@Service
public class VehiculoService {

    private static final Logger log = LoggerFactory.getLogger(VehiculoService.class);

    @Autowired
    private VehiculoRepository vehiculoRepository;

    public List<Vehiculo> listarTodo() {
        return vehiculoRepository.findAll();
    }

    public Optional<Vehiculo> buscarPorId(Long idVehiculo) {
        return vehiculoRepository.findById(idVehiculo);
    }

    public List<Vehiculo> listarActivos(boolean activo) {
        return vehiculoRepository.findByActivo(activo);
    }

    public Vehiculo guardar(VehiculoDTO dto) {
        if (vehiculoRepository.findByPatente(dto.getPatente()).isPresent()) {
            throw new IllegalArgumentException("Ya existe un vehículo con la patente: " + dto.getPatente());
        }
        Vehiculo vehiculo = new Vehiculo();
        vehiculo.setPatente(dto.getPatente());
        vehiculo.setMarca(dto.getMarca());
        vehiculo.setModelo(dto.getModelo());
        vehiculo.setCapacidadKg(dto.getCapacidadKg());
        vehiculo.setActivo(true);
        log.info("Creando vehículo: {}", dto.getPatente());
        return vehiculoRepository.save(vehiculo);
    }

    public Vehiculo actualizar(Long idVehiculo, VehiculoDTO dto) {
        Vehiculo existente = vehiculoRepository.findById(idVehiculo)
                .orElseThrow(() -> new VehiculoNotFoundException(idVehiculo));
        existente.setPatente(dto.getPatente());
        existente.setMarca(dto.getMarca());
        existente.setModelo(dto.getModelo());
        existente.setCapacidadKg(dto.getCapacidadKg());
        log.info("Actualizando vehículo con id: {}", idVehiculo);
        return vehiculoRepository.save(existente);
    }

    public void eliminar(Long idVehiculo) {
        vehiculoRepository.findById(idVehiculo)
                .orElseThrow(() -> new VehiculoNotFoundException(idVehiculo));
        log.info("Eliminando vehículo con id: {}", idVehiculo);
        vehiculoRepository.deleteById(idVehiculo);
    }
}