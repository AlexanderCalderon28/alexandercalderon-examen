package com.example.service_vehiculos.exception;

public class VehiculoNotFoundException extends RuntimeException {
    public VehiculoNotFoundException(Long idVehiculo) {
        super("Vehículo no encontrado con id: " + idVehiculo);
    }
}