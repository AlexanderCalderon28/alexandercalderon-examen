package com.example.service_vehiculos.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

@Data
public class VehiculoDTO {
    @NotBlank(message = "La patente es obligatoria")
    private String patente;
    @NotBlank(message = "La marca es obligatoria")
    private String marca;
    @NotBlank(message = "El modelo es obligatorio")
    private String modelo;
    @NotNull @Positive(message = "La capacidad debe ser mayor a 0")
    private Double capacidadKg;
}