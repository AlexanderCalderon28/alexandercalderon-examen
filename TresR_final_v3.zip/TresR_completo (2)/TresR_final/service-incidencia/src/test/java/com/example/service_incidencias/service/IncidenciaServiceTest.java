package com.example.service_incidencias.service;

import com.example.service_incidencias.exception.IncidenciaNotFoundException;
import com.example.service_incidencias.model.Incidencia;
import com.example.service_incidencias.repository.IncidenciaRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class IncidenciaServiceTest {

    @Mock
    private IncidenciaRepository incidenciaRepository;

    @InjectMocks
    private IncidenciaService incidenciaService;

    @Test
    @DisplayName("Listar todas las incidencias retorna lista correcta")
    void listarTodas_retornaLista() {
        Incidencia i = new Incidencia();
        i.setIdIncidencia(1L);
        i.setEstado("ABIERTA");

        when(incidenciaRepository.findAll()).thenReturn(List.of(i));

        List<Incidencia> resultado = incidenciaService.listarTodas();

        assertFalse(resultado.isEmpty());
        assertEquals("ABIERTA", resultado.get(0).getEstado());
    }

    @Test
    @DisplayName("Crear incidencia asigna estado ABIERTA automáticamente")
    void guardar_asignaEstadoAbierta() {
        com.example.service_incidencias.dto.IncidenciaDTO dto = new com.example.service_incidencias.dto.IncidenciaDTO();
        dto.setRecoleccionId(1L);
        dto.setTipo("ACCIDENTE");
        dto.setDescripcion("Vehículo averiado");
        dto.setFecha(LocalDate.now());

        Incidencia guardada = new Incidencia();
        guardada.setEstado("ABIERTA");

        when(incidenciaRepository.save(any(Incidencia.class))).thenReturn(guardada);

        Incidencia resultado = incidenciaService.guardar(dto);

        assertEquals("ABIERTA", resultado.getEstado());
        verify(incidenciaRepository, times(1)).save(any(Incidencia.class));
    }

    @Test
    @DisplayName("Listar incidencias por estado RESUELTA retorna filtradas")
    void listarPorEstado_retornaFiltradas() {
        Incidencia i = new Incidencia();
        i.setEstado("RESUELTA");

        when(incidenciaRepository.findByEstado("RESUELTA")).thenReturn(List.of(i));

        List<Incidencia> resultado = incidenciaService.listarPorEstado("RESUELTA");

        assertEquals(1, resultado.size());
        assertEquals("RESUELTA", resultado.get(0).getEstado());
    }

    @Test
    @DisplayName("Eliminar incidencia inexistente lanza excepción")
    void eliminar_noExiste_lanzaExcepcion() {
        when(incidenciaRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(IncidenciaNotFoundException.class, () -> incidenciaService.eliminar(99L));
    }
}
