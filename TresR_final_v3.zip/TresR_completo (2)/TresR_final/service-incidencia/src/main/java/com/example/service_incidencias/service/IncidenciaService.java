package com.example.service_incidencias.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service_incidencias.dto.IncidenciaDTO;
import com.example.service_incidencias.exception.IncidenciaNotFoundException;
import com.example.service_incidencias.model.Incidencia;
import com.example.service_incidencias.repository.IncidenciaRepository;

@Service
public class IncidenciaService {

    private static final Logger log = LoggerFactory.getLogger(IncidenciaService.class);

    @Autowired
    private IncidenciaRepository incidenciaRepository;

    public List<Incidencia> listarTodas() {
        return incidenciaRepository.findAll();
    }

    public Optional<Incidencia> buscarPorId(Long idIncidencia) {
        return incidenciaRepository.findById(idIncidencia);
    }

    public List<Incidencia> listarPorEstado(String estado) {
        return incidenciaRepository.findByEstado(estado);
    }

    public List<Incidencia> listarPorRecoleccion(Long recoleccionId) {
        return incidenciaRepository.findByRecoleccionId(recoleccionId);
    }

    public Incidencia guardar(IncidenciaDTO dto) {
        Incidencia incidencia = new Incidencia();
        incidencia.setRecoleccionId(dto.getRecoleccionId());
        incidencia.setTipo(dto.getTipo());
        incidencia.setDescripcion(dto.getDescripcion());
        incidencia.setFecha(dto.getFecha());
        incidencia.setEstado("ABIERTA"); // siempre empieza ABIERTA
        log.info("Creando incidencia para recolección {}", dto.getRecoleccionId());
        return incidenciaRepository.save(incidencia);
    }

    public Incidencia actualizar(Long idIncidencia, IncidenciaDTO dto) {
        Incidencia existente = incidenciaRepository.findById(idIncidencia)
                .orElseThrow(() -> new IncidenciaNotFoundException(idIncidencia));
        existente.setRecoleccionId(dto.getRecoleccionId());
        existente.setTipo(dto.getTipo());
        existente.setDescripcion(dto.getDescripcion());
        existente.setFecha(dto.getFecha());
        log.info("Actualizando incidencia con id: {}", idIncidencia);
        return incidenciaRepository.save(existente);
    }

    public void eliminar(Long idIncidencia) {
        incidenciaRepository.findById(idIncidencia)
                .orElseThrow(() -> new IncidenciaNotFoundException(idIncidencia));
        log.info("Eliminando incidencia con id: {}", idIncidencia);
        incidenciaRepository.deleteById(idIncidencia);
    }
}