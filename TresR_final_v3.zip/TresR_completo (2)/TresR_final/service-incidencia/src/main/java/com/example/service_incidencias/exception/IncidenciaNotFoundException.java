package com.example.service_incidencias.exception;

public class IncidenciaNotFoundException extends RuntimeException {
    public IncidenciaNotFoundException(Long idIncidencia) {
        super("Incidencia no encontrada con id: " + idIncidencia);
    }
}