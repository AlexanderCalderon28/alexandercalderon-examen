package com.example.service_incidencias.repository;

import com.example.service_incidencias.model.Incidencia;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface IncidenciaRepository extends JpaRepository<Incidencia, Long> {
    List<Incidencia> findByEstado(String estado);
    List<Incidencia> findByRecoleccionId(Long recoleccionId);
}