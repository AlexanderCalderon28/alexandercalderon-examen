package com.example.service_incidencias.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDate;

@Data
public class IncidenciaDTO {
    @NotNull(message = "El id de recolección es obligatorio")
    private Long recoleccionId;
    @NotBlank(message = "El tipo es obligatorio")
    private String tipo;
    @NotBlank(message = "La descripción es obligatoria")
    private String descripcion;
    @NotNull(message = "La fecha es obligatoria")
    private LocalDate fecha;
}