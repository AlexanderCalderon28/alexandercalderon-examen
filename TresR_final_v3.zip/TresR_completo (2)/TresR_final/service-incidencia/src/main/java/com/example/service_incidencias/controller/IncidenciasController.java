package com.example.service_incidencias.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.service_incidencias.dto.IncidenciaDTO;
import com.example.service_incidencias.model.Incidencia;
import com.example.service_incidencias.service.IncidenciaService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@Tag(name = "Incidencias", description = "Gestión de incidencias del sistema TresR")
@RestController
@RequestMapping("/incidencias")
public class IncidenciasController {

    private static final Logger log = LoggerFactory.getLogger(IncidenciasController.class);

    @Autowired
    private IncidenciaService incidenciaService;

    @Operation(summary = "Listar todas las incidencias")
    @ApiResponse(responseCode = "200", description = "Lista obtenida correctamente")
    @GetMapping
    public List<Incidencia> listarTodas() {
        log.info("GET /incidencias");
        return incidenciaService.listarTodas();
    }

    @Operation(summary = "Obtener incidencia por ID")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Incidencia encontrada"),
        @ApiResponse(responseCode = "404", description = "Incidencia no encontrada")
    })
    @GetMapping("/{idIncidencia}")
    public ResponseEntity<Incidencia> obtenerPorId(@PathVariable Long idIncidencia) {
        log.info("GET /incidencias/{}", idIncidencia);
        return incidenciaService.buscarPorId(idIncidencia)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Listar incidencias por estado (ABIERTA / RESUELTA)")
    @ApiResponse(responseCode = "200", description = "Lista filtrada por estado")
    @GetMapping("/estado/{estado}")
    public List<Incidencia> listarPorEstado(@PathVariable String estado) {
        log.info("GET /incidencias/estado/{}", estado);
        return incidenciaService.listarPorEstado(estado);
    }

    @Operation(summary = "Listar incidencias por recolección")
    @ApiResponse(responseCode = "200", description = "Lista filtrada por recolección")
    @GetMapping("/recoleccion/{recoleccionId}")
    public List<Incidencia> listarPorRecoleccion(@PathVariable Long recoleccionId) {
        log.info("GET /incidencias/recoleccion/{}", recoleccionId);
        return incidenciaService.listarPorRecoleccion(recoleccionId);
    }

    @Operation(summary = "Crear incidencia nueva")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Incidencia creada con estado ABIERTA"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PostMapping
    public ResponseEntity<Incidencia> crear(@RequestBody @Valid IncidenciaDTO dto) {
        log.info("POST /incidencias");
        return ResponseEntity.status(HttpStatus.CREATED).body(incidenciaService.guardar(dto));
    }

    @Operation(summary = "Actualizar incidencia existente")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Incidencia actualizada"),
        @ApiResponse(responseCode = "404", description = "Incidencia no encontrada")
    })
    @PutMapping("/{idIncidencia}")
    public ResponseEntity<Incidencia> actualizar(@PathVariable Long idIncidencia,
                                                  @RequestBody @Valid IncidenciaDTO dto) {
        log.info("PUT /incidencias/{}", idIncidencia);
        return ResponseEntity.ok(incidenciaService.actualizar(idIncidencia, dto));
    }

    @Operation(summary = "Eliminar incidencia")
    @ApiResponses({
        @ApiResponse(responseCode = "204", description = "Incidencia eliminada"),
        @ApiResponse(responseCode = "404", description = "Incidencia no encontrada")
    })
    @DeleteMapping("/{idIncidencia}")
    public ResponseEntity<Void> eliminar(@PathVariable Long idIncidencia) {
        log.info("DELETE /incidencias/{}", idIncidencia);
        incidenciaService.eliminar(idIncidencia);
        return ResponseEntity.noContent().build();
    }
}