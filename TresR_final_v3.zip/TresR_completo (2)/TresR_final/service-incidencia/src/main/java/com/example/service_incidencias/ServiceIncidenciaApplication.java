package com.example.service_incidencias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceIncidenciaApplication {
    public static void main(String[] args) {
        SpringApplication.run(ServiceIncidenciaApplication.class, args);
    }
}