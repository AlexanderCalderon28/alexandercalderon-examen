package com.example.service_incidencias.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Incidencia {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idIncidencia;
    private Long recoleccionId;
    private String tipo;
    private String descripcion;
    private LocalDate fecha;
    private String estado; 
}