package com.example.service_materiales.service;

import com.example.service_materiales.dto.MaterialDTO;
import com.example.service_materiales.exception.MaterialNotFoundException;
import com.example.service_materiales.model.Material;
import com.example.service_materiales.repository.MaterialRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class MaterialServiceTest {

    @Mock
    private MaterialRepository materialRepository;

    @InjectMocks
    private MaterialService materialService;

    @Test
    @DisplayName("Listar todos los materiales retorna lista correcta")
    void listarTodos_retornaLista() {
        Material m = new Material();
        m.setIdMaterial(1L);
        m.setNombreMaterial("Cartón");
        m.setActivo(true);

        when(materialRepository.findAll()).thenReturn(List.of(m));

        List<Material> resultado = materialService.listarTodos();

        assertFalse(resultado.isEmpty());
        assertEquals("Cartón", resultado.get(0).getNombreMaterial());
        verify(materialRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Buscar material por id inexistente retorna vacío")
    void buscarPorId_noExiste_retornaVacio() {
        when(materialRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Material> resultado = materialService.buscarPorId(99L);

        assertTrue(resultado.isEmpty());
        verify(materialRepository, times(1)).findById(99L);
    }

    @Test
    @DisplayName("Listar materiales activos retorna solo activos")
    void listarActivos_retornaSoloActivos() {
        Material m = new Material();
        m.setActivo(true);

        when(materialRepository.findByActivo(true)).thenReturn(List.of(m));

        List<Material> resultado = materialService.listarActivos();

        assertEquals(1, resultado.size());
        assertTrue(resultado.get(0).isActivo());
    }

    @Test
    @DisplayName("Eliminar material inexistente lanza excepción")
    void eliminar_noExiste_lanzaExcepcion() {
        when(materialRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(MaterialNotFoundException.class, () -> materialService.eliminar(99L));
    }
}
