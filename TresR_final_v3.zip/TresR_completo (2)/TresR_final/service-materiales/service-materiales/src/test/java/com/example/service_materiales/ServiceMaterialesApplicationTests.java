package com.example.service_materiales;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceMaterialesApplicationTests {

	@Test
	void contextLoads() {
	}

}
