package com.example.service_materiales.repository;

import com.example.service_materiales.model.Material;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface MaterialRepository extends JpaRepository<Material, Long> {

    // Buscar materiales activos
    List<Material> findByActivo(boolean activo);
}

