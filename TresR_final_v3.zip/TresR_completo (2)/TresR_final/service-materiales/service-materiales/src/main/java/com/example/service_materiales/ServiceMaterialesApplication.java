package com.example.service_materiales;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceMaterialesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceMaterialesApplication.class, args);
	}

}
