package com.example.service_materiales.service;

import com.example.service_materiales.dto.MaterialDTO;
import com.example.service_materiales.exception.MaterialNotFoundException;
import com.example.service_materiales.model.CategoriaMaterial;
import com.example.service_materiales.model.Material;
import com.example.service_materiales.repository.CategoriaMaterialRepository;
import com.example.service_materiales.repository.MaterialRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class MaterialService {

    private static final Logger log = LoggerFactory.getLogger(MaterialService.class);

    @Autowired
    private MaterialRepository materialRepository;

    @Autowired
    private CategoriaMaterialRepository categoriaMaterialRepository;

    public List<Material> listarTodos() {
        log.info("Listando todos los materiales");
        return materialRepository.findAll();
    }

    public Optional<Material> buscarPorId(Long idMaterial) {
        log.info("Buscando material con id {}", idMaterial);
        return materialRepository.findById(idMaterial);
    }

    public List<Material> listarActivos() {
        log.info("Listando materiales activos");
        return materialRepository.findByActivo(true);
    }

    public Material guardar(MaterialDTO dto) {
        try {
            Material material = new Material();
            material.setNombreMaterial(dto.getNombreMaterial());
            material.setDescripcion(dto.getDescripcion());
            material.setPrecioPorKg(dto.getPrecioPorKg());
            material.setActivo(dto.isActivo());

            // Si viene categoriaId, buscamos el objeto y lo asociamos
            if (dto.getCategoriaId() != null) {
                CategoriaMaterial categoria = categoriaMaterialRepository.findById(dto.getCategoriaId())
                        .orElseThrow(() -> new RuntimeException("Categoria no encontrada con id: " + dto.getCategoriaId()));
                material.setCategoria(categoria);
            }

            log.info("Guardando material: {}", material.getNombreMaterial());
            return materialRepository.save(material);
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error al guardar material: {}", e.getMessage());
            throw new RuntimeException("No se pudo guardar el material");
        }
    }

    public Material actualizar(Long idMaterial, MaterialDTO dto) {
        try {
            Material material = materialRepository.findById(idMaterial)
                    .orElseThrow(() -> new MaterialNotFoundException("Material no encontrado con id: " + idMaterial));

            material.setNombreMaterial(dto.getNombreMaterial());
            material.setDescripcion(dto.getDescripcion());
            material.setPrecioPorKg(dto.getPrecioPorKg());
            material.setActivo(dto.isActivo());

            if (dto.getCategoriaId() != null) {
                CategoriaMaterial categoria = categoriaMaterialRepository.findById(dto.getCategoriaId())
                        .orElseThrow(() -> new RuntimeException("Categoria no encontrada con id: " + dto.getCategoriaId()));
                material.setCategoria(categoria);
            }

            log.info("Actualizando material con id {}", idMaterial);
            return materialRepository.save(material);
        } catch (MaterialNotFoundException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error al actualizar material: {}", e.getMessage());
            throw new RuntimeException("No se pudo actualizar el material");
        }
    }

    public void eliminar(Long idMaterial) {
        try {
            if (!materialRepository.existsById(idMaterial)) {
                throw new MaterialNotFoundException("Material no encontrado con id: " + idMaterial);
            }
            log.info("Eliminando material con id {}", idMaterial);
            materialRepository.deleteById(idMaterial);
        } catch (MaterialNotFoundException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error al eliminar material: {}", e.getMessage());
            throw new RuntimeException("No se pudo eliminar el material");
        }
    }
}
