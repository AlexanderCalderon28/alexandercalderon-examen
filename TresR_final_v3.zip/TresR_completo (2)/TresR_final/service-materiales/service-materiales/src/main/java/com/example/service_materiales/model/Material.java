package com.example.service_materiales.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Material {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idMaterial;

    @NotBlank(message = "El nombre del material es obligatorio")
    private String nombreMaterial;

    private String descripcion;

    @NotNull(message = "El precio por kg es obligatorio")
    @Positive(message = "El precio por kg debe ser mayor a 0")
    private Double precioPorKg;

    private boolean activo;

    @ManyToOne
    @JoinColumn(name = "categoria_id")
    private CategoriaMaterial categoria; // Relacion con CategoriaMaterial (mismo microservicio)
}
