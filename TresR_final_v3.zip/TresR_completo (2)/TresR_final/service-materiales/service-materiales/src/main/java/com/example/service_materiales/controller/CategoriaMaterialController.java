package com.example.service_materiales.controller;

import java.util.List;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.service_materiales.model.CategoriaMaterial;
import com.example.service_materiales.repository.CategoriaMaterialRepository;

@RestController
@RequestMapping("/materiales/categorias")
public class CategoriaMaterialController {

    @Autowired
    private CategoriaMaterialRepository repository;

    @Operation(summary = "Listar categorías de material", description = "Retorna el catálogo de categorías de materiales reciclables (ej: Papel, Metal, Plástico, Vidrio)")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Catálogo retornado correctamente")
    })
    @GetMapping
    public ResponseEntity<List<CategoriaMaterial>> listar() {
        return ResponseEntity.ok(repository.findAll());
    }

    @Operation(summary = "Crear categoría de material", description = "Registra una nueva categoría de material reciclable. El nombre no puede estar vacío.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Categoría creada correctamente"),
        @ApiResponse(responseCode = "400", description = "Nombre vacío o datos inválidos")
    })
    @PostMapping
    public ResponseEntity<CategoriaMaterial> crear(@Valid @RequestBody CategoriaMaterial categoria) {
        return ResponseEntity.ok(repository.save(categoria));
    }
}
