package com.example.service_materiales.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

@Data
public class MaterialDTO {

    @NotBlank(message = "El nombre del material es obligatorio")
    private String nombreMaterial;

    private String descripcion;

    @NotNull(message = "El precio por kg es obligatorio")
    @Positive(message = "El precio por kg debe ser mayor a 0")
    private Double precioPorKg;

    private boolean activo;

    private Long categoriaId; // Se recibe el ID, el service busca el objeto
}
