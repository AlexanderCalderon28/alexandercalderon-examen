package com.example.service_materiales.repository;

import com.example.service_materiales.model.CategoriaMaterial;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CategoriaMaterialRepository extends JpaRepository<CategoriaMaterial, Long> {

    CategoriaMaterial findByNombre(String nombre);
}
