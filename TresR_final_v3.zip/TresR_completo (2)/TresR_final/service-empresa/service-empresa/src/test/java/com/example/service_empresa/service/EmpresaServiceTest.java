package com.example.service_empresa.service;

import com.example.service_empresa.dto.EmpresaDTO;
import com.example.service_empresa.exception.EmpresaNotFoundException;
import com.example.service_empresa.model.Empresa;
import com.example.service_empresa.model.TipoEmpresa;
import com.example.service_empresa.repository.EmpresaRepository;
import com.example.service_empresa.repository.TipoEmpresaRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class EmpresaServiceTest {

    @Mock
    private EmpresaRepository empresaRepository;

    @Mock
    private TipoEmpresaRepository tipoEmpresaRepository;

    @InjectMocks
    private EmpresaService empresaService;

    @Test
    @DisplayName("Listar todas las empresas retorna lista correcta")
    void listarTodo_retornaLista() {
        // Given
        Empresa e = new Empresa();
        e.setIdEmpresa(1L);
        e.setNombreEmpresa("TresR SpA");
        when(empresaRepository.findAll()).thenReturn(List.of(e));

        // When
        List<Empresa> resultado = empresaService.listarTodo();

        // Then
        assertFalse(resultado.isEmpty());
        assertEquals("TresR SpA", resultado.get(0).getNombreEmpresa());
        verify(empresaRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Buscar empresa por id inexistente retorna vacío")
    void buscarPorId_noExiste_retornaVacio() {
        // Given
        when(empresaRepository.findById(99L)).thenReturn(Optional.empty());

        // When
        Optional<Empresa> resultado = empresaService.buscarPorId(99L);

        // Then
        assertTrue(resultado.isEmpty());
    }

    @Test
    @DisplayName("Guardar empresa sin tipoEmpresaId no consulta TipoEmpresaRepository")
    void guardar_sinTipoEmpresa_noConsultaTipo() {
        // Given
        EmpresaDTO dto = new EmpresaDTO();
        dto.setRutEmpresa("76123456-7");
        dto.setNombreEmpresa("Reciclajes Ltda");
        dto.setEmailEmpresa("contacto@reciclajes.cl");
        dto.setTelefono("+56912345678");

        when(empresaRepository.save(any(Empresa.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // When
        Empresa resultado = empresaService.guardar(dto);

        // Then
        assertEquals("Reciclajes Ltda", resultado.getNombreEmpresa());
        verify(tipoEmpresaRepository, never()).findById(any());
        verify(empresaRepository, times(1)).save(any(Empresa.class));
    }

    @Test
    @DisplayName("Guardar empresa con tipoEmpresaId inexistente lanza excepción")
    void guardar_tipoEmpresaInexistente_lanzaExcepcion() {
        // Given
        EmpresaDTO dto = new EmpresaDTO();
        dto.setTipoEmpresaId(99L);
        when(tipoEmpresaRepository.findById(99L)).thenReturn(Optional.empty());

        // When / Then
        assertThrows(RuntimeException.class, () -> empresaService.guardar(dto));
        verify(empresaRepository, never()).save(any());
    }

    @Test
    @DisplayName("Guardar empresa con tipoEmpresaId válido asocia el tipo correctamente")
    void guardar_conTipoEmpresaValido_asociaTipo() {
        // Given
        TipoEmpresa tipo = new TipoEmpresa();
        tipo.setId(1L);
        tipo.setNombre("Manufactura");

        EmpresaDTO dto = new EmpresaDTO();
        dto.setNombreEmpresa("Industrias ABC");
        dto.setTipoEmpresaId(1L);

        when(tipoEmpresaRepository.findById(1L)).thenReturn(Optional.of(tipo));
        when(empresaRepository.save(any(Empresa.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // When
        Empresa resultado = empresaService.guardar(dto);

        // Then
        assertNotNull(resultado.getTipoEmpresa());
        assertEquals("Manufactura", resultado.getTipoEmpresa().getNombre());
    }

    @Test
    @DisplayName("Actualizar empresa inexistente lanza EmpresaNotFoundException")
    void actualizar_noExiste_lanzaExcepcion() {
        // Given
        when(empresaRepository.findById(99L)).thenReturn(Optional.empty());
        EmpresaDTO dto = new EmpresaDTO();

        // When / Then
        assertThrows(EmpresaNotFoundException.class, () -> empresaService.actualizar(99L, dto));
    }

    @Test
    @DisplayName("Eliminar empresa inexistente lanza EmpresaNotFoundException")
    void eliminar_noExiste_lanzaExcepcion() {
        // Given
        when(empresaRepository.existsById(99L)).thenReturn(false);

        // When / Then
        assertThrows(EmpresaNotFoundException.class, () -> empresaService.eliminar(99L));
        verify(empresaRepository, never()).deleteById(any());
    }

    @Test
    @DisplayName("Eliminar empresa existente elimina correctamente")
    void eliminar_existente_eliminaCorrectamente() {
        // Given
        when(empresaRepository.existsById(1L)).thenReturn(true);

        // When
        empresaService.eliminar(1L);

        // Then
        verify(empresaRepository, times(1)).deleteById(1L);
    }
}
