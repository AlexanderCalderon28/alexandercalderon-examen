package com.example.service_empresa.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service_empresa.dto.EmpresaDTO;
import com.example.service_empresa.exception.EmpresaNotFoundException;
import com.example.service_empresa.model.Empresa;
import com.example.service_empresa.model.TipoEmpresa;
import com.example.service_empresa.repository.EmpresaRepository;
import com.example.service_empresa.repository.TipoEmpresaRepository;

@Service
public class EmpresaService {

    private static final Logger log = LoggerFactory.getLogger(EmpresaService.class);

    @Autowired
    private EmpresaRepository empresaRepository;

    @Autowired
    private TipoEmpresaRepository tipoEmpresaRepository;

    public List<Empresa> listarTodo() {
        log.info("Listando todas las empresas");
        return empresaRepository.findAll();
    }

    public Optional<Empresa> buscarPorId(Long idEmpresa) {
        log.info("Buscando empresa con id {}", idEmpresa);
        return empresaRepository.findById(idEmpresa);
    }

    public Empresa guardar(EmpresaDTO dto) {
        try {
            Empresa empresa = new Empresa();
            empresa.setRutEmpresa(dto.getRutEmpresa());
            empresa.setNombreEmpresa(dto.getNombreEmpresa());
            empresa.setEmailEmpresa(dto.getEmailEmpresa());
            empresa.setTelefono(dto.getTelefono());

            // Si viene tipoEmpresaId, buscamos el objeto y lo asociamos
            if (dto.getTipoEmpresaId() != null) {
                TipoEmpresa tipo = tipoEmpresaRepository.findById(dto.getTipoEmpresaId())
                        .orElseThrow(() -> new RuntimeException("TipoEmpresa no encontrado con id: " + dto.getTipoEmpresaId()));
                empresa.setTipoEmpresa(tipo);
            }

            log.info("Guardando empresa: {}", empresa.getNombreEmpresa());
            return empresaRepository.save(empresa);
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error al guardar empresa: {}", e.getMessage());
            throw new RuntimeException("No se pudo guardar la empresa");
        }
    }

    public Empresa actualizar(Long idEmpresa, EmpresaDTO dto) {
        try {
            Empresa empresa = empresaRepository.findById(idEmpresa)
                    .orElseThrow(() -> new EmpresaNotFoundException("Empresa no encontrada con id: " + idEmpresa));

            empresa.setRutEmpresa(dto.getRutEmpresa());
            empresa.setNombreEmpresa(dto.getNombreEmpresa());
            empresa.setEmailEmpresa(dto.getEmailEmpresa());
            empresa.setTelefono(dto.getTelefono());

            if (dto.getTipoEmpresaId() != null) {
                TipoEmpresa tipo = tipoEmpresaRepository.findById(dto.getTipoEmpresaId())
                        .orElseThrow(() -> new RuntimeException("TipoEmpresa no encontrado con id: " + dto.getTipoEmpresaId()));
                empresa.setTipoEmpresa(tipo);
            }

            log.info("Actualizando empresa con id {}", idEmpresa);
            return empresaRepository.save(empresa);
        } catch (EmpresaNotFoundException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error al actualizar empresa: {}", e.getMessage());
            throw new RuntimeException("No se pudo actualizar la empresa");
        }
    }

    public void eliminar(Long idEmpresa) {
        try {
            if (!empresaRepository.existsById(idEmpresa)) {
                throw new EmpresaNotFoundException("Empresa no encontrada con id: " + idEmpresa);
            }
            log.info("Eliminando empresa con id {}", idEmpresa);
            empresaRepository.deleteById(idEmpresa);
        } catch (EmpresaNotFoundException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error al eliminar empresa: {}", e.getMessage());
            throw new RuntimeException("No se pudo eliminar la empresa");
        }
    }
}
