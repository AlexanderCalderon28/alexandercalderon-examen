package com.example.service_empresa.exception;

public class EmpresaNotFoundException extends RuntimeException {
    public EmpresaNotFoundException(String mensaje) {
        super(mensaje);
    }
}
