package com.example.service_empresa.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class EmpresaDTO {

    @NotBlank(message = "El RUT es obligatorio")
    private String rutEmpresa;

    @NotBlank(message = "El nombre es obligatorio")
    private String nombreEmpresa;

    @Email(message = "El email no tiene formato valido")
    @NotBlank(message = "El email es obligatorio")
    private String emailEmpresa;

    @NotBlank(message = "El telefono es obligatorio")
    private String telefono;

    private Long tipoEmpresaId; // Se recibe el ID, el service busca el objeto
}
