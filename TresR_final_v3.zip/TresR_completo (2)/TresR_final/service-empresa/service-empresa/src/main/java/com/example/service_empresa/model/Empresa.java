package com.example.service_empresa.model;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Empresa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idEmpresa;

    @NotBlank(message = "El RUT es obligatorio")
    private String rutEmpresa;

    @NotBlank(message = "El nombre es obligatorio")
    private String nombreEmpresa;

    @Email(message = "El email no tiene formato valido")
    @NotBlank(message = "El email es obligatorio")
    private String emailEmpresa;

    @NotBlank(message = "El telefono es obligatorio")
    private String telefono;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "tipo_empresa_id")
    private TipoEmpresa tipoEmpresa; // Relacion con TipoEmpresa (mismo microservicio)
}
