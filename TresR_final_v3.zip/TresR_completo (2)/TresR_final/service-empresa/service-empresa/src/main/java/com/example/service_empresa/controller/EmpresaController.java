package com.example.service_empresa.controller;

import java.util.List;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.service_empresa.dto.EmpresaDTO;
import com.example.service_empresa.model.Empresa;
import com.example.service_empresa.service.EmpresaService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/empresas")
public class EmpresaController {

    private static final Logger log = LoggerFactory.getLogger(EmpresaController.class);

    @Autowired
    private EmpresaService empresaService;

    @Operation(summary = "Listar empresas", description = "Retorna todas las empresas cliente registradas en el sistema")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista de empresas obtenida correctamente")
    })
    @GetMapping
    public ResponseEntity<List<Empresa>> listar() {
        log.info("GET /empresas - listando todas las empresas");
        return ResponseEntity.ok(empresaService.listarTodo());
    }

    @Operation(summary = "Obtener empresa por ID", description = "Busca y retorna una empresa específica según su ID")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Empresa encontrada"),
        @ApiResponse(responseCode = "404", description = "Empresa no encontrada con el ID proporcionado")
    })
    @GetMapping("/{idEmpresa}")
    public ResponseEntity<Empresa> buscarPorId(@PathVariable Long idEmpresa) {
        log.info("GET /empresas/{}", idEmpresa);
        return empresaService.buscarPorId(idEmpresa)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Crear empresa", description = "Registra una nueva empresa cliente. El RUT debe ser único en el sistema.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Empresa creada correctamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos o RUT ya registrado")
    })
    @PostMapping
    public ResponseEntity<Empresa> guardar(@RequestBody @Valid EmpresaDTO dto) {
        log.info("POST /empresas - creando empresa: {}", dto.getNombreEmpresa());
        return ResponseEntity.ok(empresaService.guardar(dto));
    }

    @Operation(summary = "Actualizar empresa", description = "Modifica los datos de una empresa existente según su ID")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Empresa actualizada correctamente"),
        @ApiResponse(responseCode = "404", description = "Empresa no encontrada")
    })
    @PutMapping("/{idEmpresa}")
    public ResponseEntity<Empresa> actualizar(@PathVariable Long idEmpresa,
                                              @RequestBody @Valid EmpresaDTO dto) {
        log.info("PUT /empresas/{}", idEmpresa);
        return ResponseEntity.ok(empresaService.actualizar(idEmpresa, dto));
    }

    @Operation(summary = "Eliminar empresa", description = "Elimina permanentemente una empresa del sistema según su ID")
    @ApiResponses({
        @ApiResponse(responseCode = "204", description = "Empresa eliminada correctamente"),
        @ApiResponse(responseCode = "404", description = "Empresa no encontrada")
    })
    @DeleteMapping("/{idEmpresa}")
    public ResponseEntity<Void> eliminar(@PathVariable Long idEmpresa) {
        log.info("DELETE /empresas/{}", idEmpresa);
        empresaService.eliminar(idEmpresa);
        return ResponseEntity.noContent().build();
    }
}
