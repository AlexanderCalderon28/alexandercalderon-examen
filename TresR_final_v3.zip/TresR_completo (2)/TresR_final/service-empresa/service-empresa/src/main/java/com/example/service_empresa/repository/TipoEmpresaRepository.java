package com.example.service_empresa.repository;

import com.example.service_empresa.model.TipoEmpresa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TipoEmpresaRepository extends JpaRepository<TipoEmpresa, Long> {

    TipoEmpresa findByNombre(String nombre);
}
