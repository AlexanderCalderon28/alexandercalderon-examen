package com.example.service_empresa.controller;

import java.util.List;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.service_empresa.model.TipoEmpresa;
import com.example.service_empresa.repository.TipoEmpresaRepository;

@RestController
@RequestMapping("/empresas/tipos")
public class TipoEmpresaController {

    @Autowired
    private TipoEmpresaRepository repository;

    @Operation(summary = "Listar tipos de empresa", description = "Retorna el catálogo completo de tipos de empresa disponibles (ej: Manufactura, Minería, Construcción)")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Catálogo retornado correctamente")
    })
    @GetMapping
    public ResponseEntity<List<TipoEmpresa>> listar() {
        return ResponseEntity.ok(repository.findAll());
    }

    @Operation(summary = "Crear tipo de empresa", description = "Registra un nuevo tipo de empresa en el catálogo. El nombre no puede estar vacío.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Tipo de empresa creado correctamente"),
        @ApiResponse(responseCode = "400", description = "Nombre vacío o datos inválidos")
    })
    @PostMapping
    public ResponseEntity<TipoEmpresa> crear(@Valid @RequestBody TipoEmpresa tipo) {
        return ResponseEntity.ok(repository.save(tipo));
    }
}
