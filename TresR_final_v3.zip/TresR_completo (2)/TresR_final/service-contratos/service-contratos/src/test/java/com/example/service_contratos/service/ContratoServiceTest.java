package com.example.service_contratos.service;

import com.example.service_contratos.dto.ContratoDTO;
import com.example.service_contratos.exception.ContratoNotFoundException;
import com.example.service_contratos.model.Contrato;
import com.example.service_contratos.repository.ContratoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Answers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Tests del ContratoService.
 * Nota: WebClient.Builder se mockea con RETURNS_DEEP_STUBS porque su API es
 * fluida (builder().get().uri().retrieve().bodyToMono()...), por lo que se
 * necesita que cada eslabón de la cadena retorne otro mock automáticamente.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class ContratoServiceTest {

    @Mock
    private ContratoRepository contratoRepository;

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private WebClient.Builder webClientBuilder;

    private ContratoService contratoService;

    @BeforeEach
    void setUp() {
        contratoService = new ContratoService();
        // Inyectamos los mocks manualmente porque los campos son @Autowired (no hay constructor)
        try {
            var repoField = ContratoService.class.getDeclaredField("contratoRepository");
            repoField.setAccessible(true);
            repoField.set(contratoService, contratoRepository);

            var webClientField = ContratoService.class.getDeclaredField("webClientBuilder");
            webClientField.setAccessible(true);
            webClientField.set(contratoService, webClientBuilder);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    @DisplayName("Listar todos los contratos retorna lista correcta")
    void listarTodo_retornaLista() {
        // Given
        Contrato c = new Contrato();
        c.setIdContrato(1L);
        c.setEstado("ACTIVO");
        when(contratoRepository.findAll()).thenReturn(List.of(c));

        // When
        List<Contrato> resultado = contratoService.listarTodo();

        // Then
        assertFalse(resultado.isEmpty());
        assertEquals("ACTIVO", resultado.get(0).getEstado());
    }

    @Test
    @DisplayName("Guardar contrato con fechaFin anterior a fechaInicio lanza excepción")
    void guardar_fechaInvalida_lanzaExcepcion() {
        // Given
        ContratoDTO dto = new ContratoDTO();
        dto.setFechaInicio(LocalDate.of(2025, 6, 1));
        dto.setFechaFin(LocalDate.of(2025, 5, 1)); // fin antes que inicio
        dto.setEmpresaId(1L);

        // When / Then
        assertThrows(IllegalArgumentException.class, () -> contratoService.guardar(dto));
        // La regla de fechas se valida ANTES de consultar al microservicio de empresas
        verify(contratoRepository, never()).save(any());
    }

    @Test
    @DisplayName("Guardar contrato válido consulta empresa vía WebClient y queda ACTIVO")
    void guardar_contratoValido_consultaEmpresaYQuedaActivo() {
        // Given
        ContratoDTO dto = new ContratoDTO();
        dto.setEmpresaId(1L);
        dto.setFechaInicio(LocalDate.of(2025, 1, 1));
        dto.setFechaFin(LocalDate.of(2025, 12, 31));
        dto.setTipoMaterial("Plástico");
        dto.setFrecuenciaRetiro("Semanal");

        // Simulamos la respuesta del microservicio de empresas
        when(webClientBuilder.build().get().uri(anyString()).retrieve().bodyToMono(Object.class))
                .thenReturn(Mono.just(new Object()));

        when(contratoRepository.save(any(Contrato.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // When
        Contrato resultado = contratoService.guardar(dto);

        // Then
        assertEquals("ACTIVO", resultado.getEstado());
        assertEquals("Plástico", resultado.getTipoMaterial());
        verify(contratoRepository, times(1)).save(any(Contrato.class));
    }

    @Test
    @DisplayName("Buscar por id inexistente retorna vacío")
    void buscarPorId_noExiste_retornaVacio() {
        // Given
        when(contratoRepository.findById(99L)).thenReturn(Optional.empty());

        // When
        Optional<Contrato> resultado = contratoService.buscarPorId(99L);

        // Then
        assertTrue(resultado.isEmpty());
    }

    @Test
    @DisplayName("Buscar por id existente enriquece el contrato con datos de empresa")
    void buscarPorId_existente_enriqueceConDatosEmpresa() {
        // Given
        Contrato contrato = new Contrato();
        contrato.setIdContrato(1L);
        contrato.setEmpresaId(5L);
        when(contratoRepository.findById(1L)).thenReturn(Optional.of(contrato));

        Object datosEmpresaMock = new Object();
        when(webClientBuilder.build().get().uri(anyString()).retrieve().bodyToMono(Object.class))
                .thenReturn(Mono.just(datosEmpresaMock));

        // When
        Optional<Contrato> resultado = contratoService.buscarPorId(1L);

        // Then
        assertTrue(resultado.isPresent());
        assertNotNull(resultado.get().getDatosEmpresa());
    }

    @Test
    @DisplayName("Si el microservicio de empresas falla, el contrato se retorna sin romper el flujo")
    void buscarPorId_microservicioEmpresaCaido_noRompeFlujo() {
        // Given
        Contrato contrato = new Contrato();
        contrato.setIdContrato(1L);
        contrato.setEmpresaId(5L);
        when(contratoRepository.findById(1L)).thenReturn(Optional.of(contrato));

        when(webClientBuilder.build().get().uri(anyString()).retrieve().bodyToMono(Object.class))
                .thenThrow(new RuntimeException("Servicio empresas no disponible"));

        // When
        Optional<Contrato> resultado = contratoService.buscarPorId(1L);

        // Then: no debe lanzar excepción, debe seguir entregando el contrato
        assertTrue(resultado.isPresent());
        assertEquals("Informacion de empresa no disponible actualmente", resultado.get().getDatosEmpresa());
    }

    @Test
    @DisplayName("Actualizar contrato inexistente lanza ContratoNotFoundException")
    void actualizar_noExiste_lanzaExcepcion() {
        // Given
        when(contratoRepository.findById(99L)).thenReturn(Optional.empty());
        ContratoDTO dto = new ContratoDTO();

        // When / Then
        assertThrows(ContratoNotFoundException.class, () -> contratoService.actualizar(99L, dto));
    }

    @Test
    @DisplayName("Eliminar contrato inexistente lanza ContratoNotFoundException")
    void eliminar_noExiste_lanzaExcepcion() {
        // Given
        when(contratoRepository.existsById(99L)).thenReturn(false);

        // When / Then
        assertThrows(ContratoNotFoundException.class, () -> contratoService.eliminar(99L));
        verify(contratoRepository, never()).deleteById(any());
    }
}
