package com.example.service_contratos.exception;

public class ContratoNotFoundException extends RuntimeException {
    public ContratoNotFoundException(String mensaje) {
        super(mensaje);
    }
}
