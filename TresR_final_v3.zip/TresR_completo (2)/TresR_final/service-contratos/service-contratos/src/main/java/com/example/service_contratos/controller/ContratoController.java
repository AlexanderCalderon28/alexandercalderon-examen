package com.example.service_contratos.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service_contratos.dto.ContratoDTO;
import com.example.service_contratos.model.Contrato;
import com.example.service_contratos.service.ContratoService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/contratos")
public class ContratoController {

    private static final Logger log = LoggerFactory.getLogger(ContratoController.class);

    @Autowired
    private ContratoService contratoService;

    @Operation(summary = "Listar contratos", description = "Retorna todos los contratos registrados")
    @GetMapping
    public List<Contrato> listar() {
        log.info("GET /contratos");
        return contratoService.listarTodo();
    }

    @Operation(summary = "Listar contratos por empresa", description = "Retorna los contratos asociados a una empresa específica")
    @GetMapping("/empresa/{empresaId}")
    public List<Contrato> listarPorEmpresa(@PathVariable Long empresaId){
        log.info("GET /contratos/empresa/{}", empresaId);
        return contratoService.listarPorEmpresa(empresaId);
    }

    @Operation(summary = "Obtener contrato por ID", description = "Busca un contrato específico según su ID")
    @GetMapping("/{idContrato}")
    public ResponseEntity<Contrato> obtener(@PathVariable Long idContrato) {
        log.info("GET /contratos/{}", idContrato);
        return contratoService.buscarPorId(idContrato)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Crear contrato", description = "Registra un nuevo contrato de servicio para una empresa")
    @PostMapping
    public ResponseEntity<Contrato>crear(@RequestBody @Valid ContratoDTO dto) {
        log.info("POST /contratos - empresa id {}", dto.getEmpresaId());
        return ResponseEntity.ok(contratoService.guardar(dto));
    }

    @Operation(summary = "Actualizar contrato", description = "Modifica los datos de un contrato existente")
    @PutMapping("/{idContrato}")
    public ResponseEntity<Contrato>  actualizar(@PathVariable Long idContrato,
                                               @RequestBody @Valid ContratoDTO dto) {
        log.info("PUT /contratos/{}", idContrato);
        return ResponseEntity.ok(contratoService.actualizar(idContrato, dto));
    }
@Operation(summary = "Eliminar contrato", description = "Elimina un contrato por su ID")
    @DeleteMapping("/{idContrato}")
    public ResponseEntity<Void> eliminar(@PathVariable Long idContrato) {
        log.info("DELETE /contratos/{}", idContrato);
        contratoService.eliminar(idContrato);
        return ResponseEntity.noContent().build();
    }
}
