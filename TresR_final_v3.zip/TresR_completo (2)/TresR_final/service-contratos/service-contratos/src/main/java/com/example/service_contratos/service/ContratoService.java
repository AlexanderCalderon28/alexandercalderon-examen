package com.example.service_contratos.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.service_contratos.dto.ContratoDTO;
import com.example.service_contratos.exception.ContratoNotFoundException;
import com.example.service_contratos.model.Contrato;
import com.example.service_contratos.repository.ContratoRepository;

@Service
public class ContratoService {

    private static final Logger log = LoggerFactory.getLogger(ContratoService.class);

    @Autowired
    private ContratoRepository contratoRepository;

    @Autowired
    private WebClient.Builder webClientBuilder;

    public List<Contrato> listarTodo() {
        log.info("Listando todos los contratos");
        return contratoRepository.findAll();
    }

    public List<Contrato> listarPorEmpresa(Long empresaId) {
        log.info("Listando contratos de empresa id {}", empresaId);
        return contratoRepository.findByEmpresaId(empresaId);
    }

    public Optional<Contrato> buscarPorId(Long idContrato) {
        log.info("Buscando contrato con id {}", idContrato);
        Contrato contrato = contratoRepository.findById(idContrato).orElse(null);
        if (contrato != null) {
            return Optional.of(enriquecerConEmpresa(contrato));
        }
        return Optional.empty();
    }

    public Contrato guardar(ContratoDTO dto) {
        try {
            // Regla de negocio: fechaFin debe ser posterior a fechaInicio
            if (!dto.getFechaFin().isAfter(dto.getFechaInicio())) {
                throw new IllegalArgumentException("La fecha de fin debe ser posterior a la fecha de inicio");
            }

            // Validamos que la empresa existe antes de guardar
            if (dto.getEmpresaId() != null) {
                Object datosEmpresa = webClientBuilder.build()
                        .get()
                        .uri("http://localhost:8081/empresas/" + dto.getEmpresaId())
                        .retrieve()
                        .bodyToMono(Object.class)
                        .block();
                log.info("Empresa id {} validada correctamente", dto.getEmpresaId());
            }

            Contrato contrato = new Contrato();
            contrato.setEmpresaId(dto.getEmpresaId());
            contrato.setFechaInicio(dto.getFechaInicio());
            contrato.setFechaFin(dto.getFechaFin());
            contrato.setTipoMaterial(dto.getTipoMaterial());
            contrato.setFrecuenciaRetiro(dto.getFrecuenciaRetiro());
            // Regla de negocio: estado siempre ACTIVO al crear
            contrato.setEstado("ACTIVO");

            log.info("Guardando contrato para empresa id {}", dto.getEmpresaId());
            return contratoRepository.save(contrato);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error al guardar contrato: {}", e.getMessage());
            throw new RuntimeException("No se pudo guardar el contrato");
        }
    }

    public Contrato actualizar(Long idContrato, ContratoDTO dto) {
        try {
            Contrato contrato = contratoRepository.findById(idContrato)
                    .orElseThrow(() -> new ContratoNotFoundException("Contrato no encontrado con id: " + idContrato));

            if (!dto.getFechaFin().isAfter(dto.getFechaInicio())) {
                throw new IllegalArgumentException("La fecha de fin debe ser posterior a la fecha de inicio");
            }

            contrato.setEmpresaId(dto.getEmpresaId());
            contrato.setFechaInicio(dto.getFechaInicio());
            contrato.setFechaFin(dto.getFechaFin());
            contrato.setTipoMaterial(dto.getTipoMaterial());
            contrato.setFrecuenciaRetiro(dto.getFrecuenciaRetiro());
            contrato.setEstado("ACTIVO");

            log.info("Actualizando contrato con id {}", idContrato);
            return contratoRepository.save(contrato);
        } catch (ContratoNotFoundException | IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error al actualizar contrato: {}", e.getMessage());
            throw new RuntimeException("No se pudo actualizar el contrato");
        }
    }

    public void eliminar(Long idContrato) {
        try {
            if (!contratoRepository.existsById(idContrato)) {
                throw new ContratoNotFoundException("Contrato no encontrado con id: " + idContrato);
            }
            log.info("Eliminando contrato con id {}", idContrato);
            contratoRepository.deleteById(idContrato);
        } catch (ContratoNotFoundException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error al eliminar contrato: {}", e.getMessage());
            throw new RuntimeException("No se pudo eliminar el contrato");
        }
    }

    // Enriquece el contrato con los datos de la empresa desde el otro microservicio
    private Contrato enriquecerConEmpresa(Contrato contrato) {
        if (contrato.getEmpresaId() != null) {
            try {
                Object empresa = webClientBuilder.build()
                        .get()
                        .uri("http://localhost:8081/empresas/" + contrato.getEmpresaId())
                        .retrieve()
                        .bodyToMono(Object.class)
                        .block();
                contrato.setDatosEmpresa(empresa);
            } catch (Exception e) {
                // Si el microservicio de empresas no esta disponible, no rompemos el flujo
                contrato.setDatosEmpresa("Informacion de empresa no disponible actualmente");
            }
        }
        return contrato;
    }
}
