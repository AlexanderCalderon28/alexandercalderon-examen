package com.example.service_contratos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceContratosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceContratosApplication.class, args);
	}

}
