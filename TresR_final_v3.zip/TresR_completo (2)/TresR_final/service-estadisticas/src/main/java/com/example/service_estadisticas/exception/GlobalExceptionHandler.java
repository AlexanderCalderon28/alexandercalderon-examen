package com.example.service_estadisticas.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    // Cuando el microservicio remoto responde con error (4xx, 5xx)
    @ExceptionHandler(WebClientResponseException.class)
    public ResponseEntity<Map<String, String>> handleWebClientResponse(WebClientResponseException ex) {
        Map<String, String> error = new HashMap<>();
        error.put("error", "El microservicio consultado respondió con error: " + ex.getStatusCode());
        return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(error);
    }

    // Cuando el microservicio remoto no responde (timeout, caído, sin conexión)
    @ExceptionHandler(WebClientRequestException.class)
    public ResponseEntity<Map<String, String>> handleWebClientRequest(WebClientRequestException ex) {
        Map<String, String> error = new HashMap<>();
        error.put("error", "No se pudo establecer comunicación con el microservicio remoto");
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(error);
    }

    // Cualquier otro error no controlado
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, String>> handleGeneral(Exception ex) {
        Map<String, String> error = new HashMap<>();
        error.put("error", "Error inesperado al generar la estadística: " + ex.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
    }
}
