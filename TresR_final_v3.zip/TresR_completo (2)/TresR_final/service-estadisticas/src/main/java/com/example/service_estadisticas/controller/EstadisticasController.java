package com.example.service_estadisticas.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.service_estadisticas.service.EstadisticaService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Estadísticas", description = "Estadísticas consolidadas del sistema TresR")
@RestController
@RequestMapping("/estadisticas")
public class EstadisticasController {

    private static final Logger log = LoggerFactory.getLogger(EstadisticasController.class);

    @Autowired
    private EstadisticaService estadisticaService;

    @Operation(summary = "Total de recolecciones")
    @ApiResponse(responseCode = "200", description = "Lista de todas las recolecciones")
    // GET /estadisticas/recolecciones
    @GetMapping("/recolecciones")
    public ResponseEntity<Object> totalRecolecciones() {
        log.info("GET /estadisticas/recolecciones");
        return ResponseEntity.ok(estadisticaService.totalRecolecciones());
    }

    @Operation(summary = "Recolecciones pendientes")
    @ApiResponse(responseCode = "200", description = "Lista de recolecciones con estado PENDIENTE")
    // GET /estadisticas/pendientes
    @GetMapping("/pendientes")
    public ResponseEntity<Object> pendientes() {
        log.info("GET /estadisticas/pendientes");
        return ResponseEntity.ok(estadisticaService.recoleccionesPendientes());
    }

    @Operation(summary = "Recolecciones realizadas")
    @ApiResponse(responseCode = "200", description = "Lista de recolecciones con estado REALIZADA")
    // GET /estadisticas/realizadas
    @GetMapping("/realizadas")
    public ResponseEntity<Object> realizadas() {
        log.info("GET /estadisticas/realizadas");
        return ResponseEntity.ok(estadisticaService.recoleccionesRealizadas());
    }

    @Operation(summary = "Total de materiales")
    @ApiResponse(responseCode = "200", description = "Lista de todos los materiales")
    // GET /estadisticas/materiales
    @GetMapping("/materiales")
    public ResponseEntity<Object> totalMateriales() {
        log.info("GET /estadisticas/materiales");
        return ResponseEntity.ok(estadisticaService.totalMateriales());
    }

    @Operation(summary = "Materiales activos")
    @ApiResponse(responseCode = "200", description = "Lista de materiales con activo = true")
    // GET /estadisticas/materiales/activos
    @GetMapping("/materiales/activos")
    public ResponseEntity<Object> materialesActivos() {
        log.info("GET /estadisticas/materiales/activos");
        return ResponseEntity.ok(estadisticaService.materialesActivos());
    }
}