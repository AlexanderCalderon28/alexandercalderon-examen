package com.example.service_estadisticas.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Service
public class EstadisticaService {

    private static final Logger log = LoggerFactory.getLogger(EstadisticaService.class);

    @Autowired
    private WebClient.Builder webClientBuilder;

    // Total de recolecciones
    public Object totalRecolecciones() {
        log.info("Consultando recolecciones a service-recolecciones");
        return webClientBuilder.build()
                .get()
                .uri("http://localhost:8083/recolecciones")
                .retrieve()
                .bodyToMono(List.class)
                .block();
    }

    // Recolecciones pendientes
    public Object recoleccionesPendientes() {
        log.info("Consultando recolecciones PENDIENTE");
        return webClientBuilder.build()
                .get()
                .uri("http://localhost:8083/recolecciones/estado/PENDIENTE")
                .retrieve()
                .bodyToMono(List.class)
                .block();
    }

    // Recolecciones realizadas
    public Object recoleccionesRealizadas() {
        log.info("Consultando recolecciones REALIZADA");
        return webClientBuilder.build()
                .get()
                .uri("http://localhost:8083/recolecciones/estado/REALIZADA")
                .retrieve()
                .bodyToMono(List.class)
                .block();
    }

    // Total de materiales activos
    public Object materialesActivos() {
        log.info("Consultando materiales activos a service-materiales");
        return webClientBuilder.build()
                .get()
                .uri("http://localhost:8084/materiales/activos")
                .retrieve()
                .bodyToMono(List.class)
                .block();
    }

    // Total de materiales
    public Object totalMateriales() {
        log.info("Consultando todos los materiales");
        return webClientBuilder.build()
                .get()
                .uri("http://localhost:8084/materiales")
                .retrieve()
                .bodyToMono(List.class)
                .block();
    }
}