package com.example.service_estadisticas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceReportesApplicationTests {

	@Test
	void contextLoads() {
	}

}
