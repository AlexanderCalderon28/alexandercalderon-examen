package com.example.service_recolecciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRecoleccionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
