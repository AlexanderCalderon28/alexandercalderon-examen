package com.example.service_recolecciones.service;

import com.example.service_recolecciones.dto.RecoleccionDTO;
import com.example.service_recolecciones.exception.RecoleccionNotFoundException;
import com.example.service_recolecciones.model.Recoleccion;
import com.example.service_recolecciones.repository.RecoleccionRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class RecoleccionServiceTest {

    @Mock
    private RecoleccionRepository recoleccionRepository;

    @Mock
    private WebClient.Builder webClientBuilder;

    @InjectMocks
    private RecoleccionService recoleccionService;

    @Test
    @DisplayName("Listar todas las recolecciones retorna lista correcta")
    void listarTodo_retornaLista() {
        // Given
        Recoleccion r = new Recoleccion();
        r.setIdRecoleccion(1L);
        r.setEstadoRecoleccion("PENDIENTE");
        when(recoleccionRepository.findAll()).thenReturn(List.of(r));

        // When
        List<Recoleccion> resultado = recoleccionService.listarTodo();

        // Then
        assertFalse(resultado.isEmpty());
        assertEquals("PENDIENTE", resultado.get(0).getEstadoRecoleccion());
        verify(recoleccionRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Al guardar una recolección el estado siempre queda PENDIENTE")
    void guardar_estadoSiemprePendiente() {
        // Given - Regla de negocio clave: sin importar lo que venga en el DTO,
        // el estado inicial es siempre PENDIENTE
        RecoleccionDTO dto = new RecoleccionDTO();
        dto.setIdContrato(1L);
        dto.setIdMaterial(2L);
        dto.setFechaRecoleccion(LocalDate.now());
        dto.setCantidadKg(100.0);

        when(recoleccionRepository.save(any(Recoleccion.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        // When
        Recoleccion resultado = recoleccionService.guardar(dto);

        // Then
        assertEquals("PENDIENTE", resultado.getEstadoRecoleccion());
        verify(recoleccionRepository, times(1)).save(any(Recoleccion.class));
    }

    @Test
    @DisplayName("Listar recolecciones por contrato retorna las correctas")
    void listarPorContrato_retornaRecoleccionesDelContrato() {
        // Given
        Recoleccion r = new Recoleccion();
        r.setIdContrato(5L);
        when(recoleccionRepository.findByIdContrato(5L)).thenReturn(List.of(r));

        // When
        List<Recoleccion> resultado = recoleccionService.listarPorContrato(5L);

        // Then
        assertEquals(1, resultado.size());
        assertEquals(5L, resultado.get(0).getIdContrato());
    }

    @Test
    @DisplayName("Buscar por id inexistente retorna Optional vacío")
    void buscarPorId_noExiste_retornaVacio() {
        // Given
        when(recoleccionRepository.findById(99L)).thenReturn(Optional.empty());

        // When
        Optional<Recoleccion> resultado = recoleccionService.buscarPorId(99L);

        // Then
        assertTrue(resultado.isEmpty());
    }

    @Test
    @DisplayName("Actualizar recolección inexistente lanza RecoleccionNotFoundException")
    void actualizar_noExiste_lanzaExcepcion() {
        // Given
        when(recoleccionRepository.findById(99L)).thenReturn(Optional.empty());

        // When / Then
        assertThrows(RecoleccionNotFoundException.class,
                () -> recoleccionService.actualizar(99L, new RecoleccionDTO()));
        verify(recoleccionRepository, never()).save(any());
    }

    @Test
    @DisplayName("Eliminar recolección inexistente lanza RecoleccionNotFoundException")
    void eliminar_noExiste_lanzaExcepcion() {
        // Given
        when(recoleccionRepository.existsById(99L)).thenReturn(false);

        // When / Then
        assertThrows(RecoleccionNotFoundException.class,
                () -> recoleccionService.eliminar(99L));
        verify(recoleccionRepository, never()).deleteById(any());
    }

    @Test
    @DisplayName("Eliminar recolección existente llama deleteById correctamente")
    void eliminar_existente_eliminaCorrectamente() {
        // Given
        when(recoleccionRepository.existsById(1L)).thenReturn(true);

        // When
        recoleccionService.eliminar(1L);

        // Then
        verify(recoleccionRepository, times(1)).deleteById(1L);
    }
}
