package com.example.service_recolecciones.repository;

import com.example.service_recolecciones.model.Recoleccion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface RecoleccionRepository extends JpaRepository<Recoleccion, Long> {

    // Buscar recolecciones por contrato
    List<Recoleccion> findByIdContrato(Long idContrato);

    // Buscar recolecciones por estado (PENDIENTE o REALIZADA)
    List<Recoleccion> findByEstadoRecoleccion(String estadoRecoleccion);
}
