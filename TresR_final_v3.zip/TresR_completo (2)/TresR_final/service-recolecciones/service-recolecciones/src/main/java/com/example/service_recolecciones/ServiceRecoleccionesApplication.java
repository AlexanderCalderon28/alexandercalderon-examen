package com.example.service_recolecciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceRecoleccionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceRecoleccionesApplication.class, args);
	}

}
