package com.example.service_recolecciones.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Recoleccion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idRecoleccion;

    private Long idContrato; // Referencia logica al microservicio de contratos

    private Long idMaterial; // Referencia logica al microservicio de materiales

    @NotNull(message = "La fecha de recoleccion es obligatoria")
    private LocalDate fechaRecoleccion;

    @Positive(message = "La cantidad en kg debe ser mayor a 0")
    private double cantidadKg;

    private String estadoRecoleccion;

    @Transient // No se guarda en la BD, se obtiene via WebClient
    private Object datosContrato;

    @Transient // No se guarda en la BD, se obtiene via WebClient
    private Object datosMaterial;
}
