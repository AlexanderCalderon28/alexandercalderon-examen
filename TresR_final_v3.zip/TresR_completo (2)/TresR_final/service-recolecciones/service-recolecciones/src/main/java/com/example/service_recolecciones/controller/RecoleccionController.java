package com.example.service_recolecciones.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service_recolecciones.dto.RecoleccionDTO;
import com.example.service_recolecciones.model.Recoleccion;
import com.example.service_recolecciones.service.RecoleccionService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/recolecciones")
public class RecoleccionController {

    private static final Logger log = LoggerFactory.getLogger(RecoleccionController.class);

    @Autowired
    private RecoleccionService recoleccionService;

    @Operation(summary = "Listar recolecciones", description = "Retorna todas las recolecciones registradas")
    @GetMapping
    public List<Recoleccion> listar() {
        log.info("GET /recolecciones");
        return recoleccionService.listarTodo();
    }

    @Operation(summary = "Listar recolecciones por contrato", description = "Retorna las recolecciones asociadas a un contrato específico")
    @GetMapping("/contrato/{idContrato}")
    public List<Recoleccion>listarPorContrato(@PathVariable Long idContrato) {
        log.info("GET /recolecciones/contrato/{}", idContrato);
        return recoleccionService.listarPorContrato(idContrato);
    }
    @Operation(summary = "Listar recolecciones por estado", description = "Filtra recolecciones según su estado (ej: PENDIENTE, REALIZADA)")
    @GetMapping("/estado/{estadoRecoleccion}")
    public List<Recoleccion> listarPorEstado(@PathVariable String estadoRecoleccion) {
        log.info("GET /recolecciones/estado/{}", estadoRecoleccion);
        return recoleccionService.listarPorEstado(estadoRecoleccion);
    }

    @Operation(summary = "Obtener recolección por ID", description = "Busca una recolección específica según su ID")
    @GetMapping("/{idRecoleccion}")
    public ResponseEntity<Recoleccion> obtener(@PathVariable Long idRecoleccion) {
        log.info("GET /recolecciones/{}", idRecoleccion);
        return recoleccionService.buscarPorId(idRecoleccion)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Crear recolección", description = "Registra una nueva recolección asociada a un contrato. El estado inicial siempre queda como PENDIENTE")
    @PostMapping
    public ResponseEntity<Recoleccion> crear(@RequestBody @Valid RecoleccionDTO dto) {
        log.info("POST /recolecciones - contrato id {}", dto.getIdContrato());
        return ResponseEntity.ok(recoleccionService.guardar(dto));
    }

    @Operation(summary = "Actualizar recolección", description = "Modifica los datos de una recolección existente")
    @PutMapping("/{idRecoleccion}")
    public ResponseEntity<Recoleccion> actualizar(@PathVariable Long idRecoleccion,
                                                  @RequestBody @Valid RecoleccionDTO dto) {
        log.info("PUT /recolecciones/{}", idRecoleccion);
        return ResponseEntity.ok(recoleccionService.actualizar(idRecoleccion, dto));
    }

    @Operation(summary = "Eliminar recolección", description = "Elimina una recolección por su ID")
    @DeleteMapping("/{idRecoleccion}")
    public ResponseEntity<Void> eliminar(@PathVariable Long idRecoleccion) {
        log.info("DELETE /recolecciones/{}", idRecoleccion);
        recoleccionService.eliminar(idRecoleccion);
        return ResponseEntity.noContent().build();
    }
}
