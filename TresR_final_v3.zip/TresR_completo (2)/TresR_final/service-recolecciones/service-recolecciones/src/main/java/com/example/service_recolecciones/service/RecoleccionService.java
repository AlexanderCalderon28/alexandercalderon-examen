package com.example.service_recolecciones.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.service_recolecciones.dto.RecoleccionDTO;
import com.example.service_recolecciones.exception.RecoleccionNotFoundException;
import com.example.service_recolecciones.model.Recoleccion;
import com.example.service_recolecciones.repository.RecoleccionRepository;

@Service
public class RecoleccionService {

    private static final Logger log = LoggerFactory.getLogger(RecoleccionService.class);

    @Autowired
    private RecoleccionRepository recoleccionRepository;

    @Autowired
    private WebClient.Builder webClientBuilder;

    public List<Recoleccion> listarTodo() {
        log.info("Listando todas las recolecciones");
        return recoleccionRepository.findAll();
    }

    public List<Recoleccion> listarPorContrato(Long idContrato) {
        log.info("Listando recolecciones del contrato id {}", idContrato);
        return recoleccionRepository.findByIdContrato(idContrato);
    }

    public List<Recoleccion> listarPorEstado(String estadoRecoleccion) {
        log.info("Listando recolecciones con estado {}", estadoRecoleccion);
        return recoleccionRepository.findByEstadoRecoleccion(estadoRecoleccion);
    }

    public Optional<Recoleccion> buscarPorId(Long idRecoleccion) {
        log.info("Buscando recoleccion con id {}", idRecoleccion);
        Recoleccion recoleccion = recoleccionRepository.findById(idRecoleccion).orElse(null);
        if (recoleccion != null) {
            return Optional.of(enriquecerConDatosRemotos(recoleccion));
        }
        return Optional.empty();
    }

    public Recoleccion guardar(RecoleccionDTO dto) {
        try {
            Recoleccion recoleccion = new Recoleccion();
            recoleccion.setIdContrato(dto.getIdContrato());
            recoleccion.setIdMaterial(dto.getIdMaterial());
            recoleccion.setFechaRecoleccion(dto.getFechaRecoleccion());
            recoleccion.setCantidadKg(dto.getCantidadKg());
            // Regla de negocio: estado siempre PENDIENTE al crear
            recoleccion.setEstadoRecoleccion("PENDIENTE");

            log.info("Guardando recoleccion para contrato id {}", dto.getIdContrato());
            return recoleccionRepository.save(recoleccion);
        } catch (Exception e) {
            log.error("Error al guardar recoleccion: {}", e.getMessage());
            throw new RuntimeException("No se pudo guardar la recoleccion");
        }
    }


    public Recoleccion actualizar(Long idRecoleccion, RecoleccionDTO dto) {
        try {
            Recoleccion recoleccion = recoleccionRepository.findById(idRecoleccion)
                    .orElseThrow(() -> new RecoleccionNotFoundException("Recoleccion no encontrada con id: " + idRecoleccion));

            recoleccion.setIdContrato(dto.getIdContrato());
            recoleccion.setIdMaterial(dto.getIdMaterial());
            recoleccion.setFechaRecoleccion(dto.getFechaRecoleccion());
            recoleccion.setCantidadKg(dto.getCantidadKg());
            recoleccion.setEstadoRecoleccion("PENDIENTE");

            log.info("Actualizando recoleccion con id {}", idRecoleccion);
            return recoleccionRepository.save(recoleccion);
        } catch (RecoleccionNotFoundException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error al actualizar recoleccion: {}", e.getMessage());
            throw new RuntimeException("No se pudo actualizar la recoleccion");
        }
    }

    public void eliminar(Long idRecoleccion) {
        try {
            if (!recoleccionRepository.existsById(idRecoleccion)) {
                throw new RecoleccionNotFoundException("Recoleccion no encontrada con id: " + idRecoleccion);
            }
            log.info("Eliminando recoleccion con id {}", idRecoleccion);
            recoleccionRepository.deleteById(idRecoleccion);
        } catch (RecoleccionNotFoundException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error al eliminar recoleccion: {}", e.getMessage());
            throw new RuntimeException("No se pudo eliminar la recoleccion");
        }
    }

    // Enriquece con datos del contrato y material desde otros microservicios
    private Recoleccion enriquecerConDatosRemotos(Recoleccion recoleccion) {
        if (recoleccion.getIdContrato() != null) {
            try {
                Object contrato = webClientBuilder.build()
                        .get()
                        .uri("http://localhost:8082/contratos/" + recoleccion.getIdContrato())
                        .retrieve()
                        .bodyToMono(Object.class)
                        .block();
                recoleccion.setDatosContrato(contrato);
            } catch (Exception e) {
                recoleccion.setDatosContrato("Informacion de contrato no disponible actualmente");
            }
        }
        if (recoleccion.getIdMaterial() != null) {
            try {
                Object material = webClientBuilder.build()
                        .get()
                        .uri("http://localhost:8084/materiales/" + recoleccion.getIdMaterial())
                        .retrieve()
                        .bodyToMono(Object.class)
                        .block();
                recoleccion.setDatosMaterial(material);
            } catch (Exception e) {
                recoleccion.setDatosMaterial("Informacion de material no disponible actualmente");
            }
        }
        return recoleccion;
    }
}
