package com.example.service_recolecciones.exception;

public class RecoleccionNotFoundException extends RuntimeException {
    public RecoleccionNotFoundException(String mensaje) {
        super(mensaje);
    }
}
