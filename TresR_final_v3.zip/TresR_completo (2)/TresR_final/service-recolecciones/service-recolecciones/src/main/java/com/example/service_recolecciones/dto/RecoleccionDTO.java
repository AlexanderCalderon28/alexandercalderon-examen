package com.example.service_recolecciones.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;
import java.time.LocalDate;

import com.example.service_recolecciones.model.Recoleccion;

@Data
public class RecoleccionDTO {

    @NotNull(message = "El ID de contrato es obligatorio")
    private Long idContrato;

    @NotNull(message = "El ID de material es obligatorio")
    private Long idMaterial;

    @NotNull(message = "La fecha de recoleccion es obligatoria")
    private LocalDate fechaRecoleccion;

    @Positive(message = "La cantidad en kg debe ser mayor a 0")
    private double cantidadKg;

    
}
