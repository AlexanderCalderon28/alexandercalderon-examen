package com.example.service_reportes.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import java.util.List;

@Service
public class ReporteService {

    private static final Logger log = LoggerFactory.getLogger(ReporteService.class);

    @Autowired
    private WebClient.Builder webClientBuilder;

    public Object obtenerEmpresas() {
        log.info("Consultando todas las empresas");
        return webClientBuilder.build()
                .get()
                .uri("http://localhost:8081/empresas")
                .retrieve()
                .bodyToMono(List.class)
                .block();
    }

    public Object obtenerContratos() {
        log.info("Consultando todos los contratos");
        return webClientBuilder.build()
                .get()
                .uri("http://localhost:8082/contratos")
                .retrieve()
                .bodyToMono(List.class)
                .block();
    }

    public Object obtenerRecolecciones() {
        log.info("Consultando todas las recolecciones");
        return webClientBuilder.build()
                .get()
                .uri("http://localhost:8083/recolecciones")
                .retrieve()
                .bodyToMono(List.class)
                .block();
    }

    public Object obtenerMateriales() {
        log.info("Consultando todos los materiales");
        return webClientBuilder.build()
                .get()
                .uri("http://localhost:8084/materiales")
                .retrieve()
                .bodyToMono(List.class)
                .block();
    }

    public Object obtenerPendientes() {
        log.info("Consultando recolecciones PENDIENTES");
        return webClientBuilder.build()
                .get()
                .uri("http://localhost:8083/recolecciones/estado/PENDIENTE")
                .retrieve()
                .bodyToMono(List.class)
                .block();
    }
}
