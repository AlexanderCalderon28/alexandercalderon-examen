package com.example.service_reportes.controller;

import com.example.service_reportes.service.ReporteService;

import io.swagger.v3.oas.annotations.Operation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/reportes")
public class ReporteController {

    private static final Logger log = LoggerFactory.getLogger(ReporteController.class);

    @Autowired
    private ReporteService reporteService;

    @Operation(summary = "Reporte de empresas", description = "Consolida información de empresas obtenida desde service-empresa")
    @GetMapping("/empresas")
    public ResponseEntity<Object> empresas()  {
        log.info("GET /reportes/empresas");
        return ResponseEntity.ok(reporteService.obtenerEmpresas());
    }

    @Operation(summary = "Reporte de contratos", description = "Consolida información de contratos obtenida desde service-contratos")
    @GetMapping("/contratos")
    public ResponseEntity<Object> contratos() {
        log.info("GET /reportes/contratos");
        return ResponseEntity.ok(reporteService.obtenerContratos());
    }

    @Operation(summary = "Reporte de recolecciones", description = "Consolida información de recolecciones obtenida desde service-recolecciones")
    @GetMapping("/recolecciones")
    public ResponseEntity<Object> recolecciones() {
        log.info("GET /reportes/recolecciones");
        return ResponseEntity.ok(reporteService.obtenerRecolecciones());
    }

    @Operation(summary = "Reporte de materiales", description = "Consolida información de materiales obtenida desde service-materiales")
    @GetMapping("/materiales")
    public ResponseEntity<Object> materiales() {
        log.info("GET /reportes/materiales");
        return ResponseEntity.ok(reporteService.obtenerMateriales());
    }

    @Operation(summary = "Reporte de pendientes", description = "Consolida las recolecciones que aún están pendientes de ejecución")
    @GetMapping("/pendientes")
    public ResponseEntity<Object> pendientes(){
        log.info("GET /reportes/pendientes");
        return ResponseEntity.ok(reporteService.obtenerPendientes());
    }
}
