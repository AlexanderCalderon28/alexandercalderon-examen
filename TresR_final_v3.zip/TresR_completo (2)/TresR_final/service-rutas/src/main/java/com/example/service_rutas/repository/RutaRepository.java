package com.example.service_rutas.repository;

import com.example.service_rutas.model.Ruta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface RutaRepository extends JpaRepository<Ruta, Long> {
    List<Ruta> findByEstado(String estado);
    List<Ruta> findByConductorId(Long conductorId);
    List<Ruta> findByVehiculoId(Long vehiculoId);
}