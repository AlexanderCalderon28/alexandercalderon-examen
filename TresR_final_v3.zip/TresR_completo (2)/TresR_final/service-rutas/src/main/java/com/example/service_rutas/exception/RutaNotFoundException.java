package com.example.service_rutas.exception;

public class RutaNotFoundException extends RuntimeException {
    public RutaNotFoundException(Long idRuta) {
        super("Ruta no encontrada con id: " + idRuta);
    }
}