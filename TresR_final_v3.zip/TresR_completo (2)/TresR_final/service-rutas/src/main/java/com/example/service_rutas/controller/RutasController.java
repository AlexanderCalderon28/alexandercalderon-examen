package com.example.service_rutas.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.service_rutas.dto.RutaDTO;
import com.example.service_rutas.model.Ruta;
import com.example.service_rutas.service.RutaService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@Tag(name = "Rutas", description = "Gestión de rutas de recolección")
@RestController
@RequestMapping("/rutas")
public class RutasController {

    private static final Logger log = LoggerFactory.getLogger(RutasController.class);

    @Autowired
    private RutaService rutaService;

    @Operation(summary = "Listar todas las rutas")
    @ApiResponse(responseCode = "200", description = "Lista obtenida correctamente")
    @GetMapping
    public List<Ruta> listarTodas() {
        log.info("GET /rutas");
        return rutaService.listarTodas();
    }

    @Operation(summary = "Obtener ruta por ID")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Ruta encontrada"),
        @ApiResponse(responseCode = "404", description = "Ruta no encontrada")
    })
    @GetMapping("/{idRuta}")
    public ResponseEntity<Ruta> obtenerPorId(@PathVariable Long idRuta) {
        log.info("GET /rutas/{}", idRuta);
        return rutaService.buscarPorId(idRuta)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Listar rutas por estado (PLANIFICADA / EN_CURSO / COMPLETADA)")
    @ApiResponse(responseCode = "200", description = "Lista filtrada por estado")
    @GetMapping("/estado/{estado}")
    public List<Ruta> listarPorEstado(@PathVariable String estado) {
        log.info("GET /rutas/estado/{}", estado);
        return rutaService.listarPorEstado(estado);
    }

    @Operation(summary = "Listar rutas por conductor")
    @ApiResponse(responseCode = "200", description = "Lista filtrada por conductor")
    @GetMapping("/conductor/{conductorId}")
    public List<Ruta> listarPorConductor(@PathVariable Long conductorId) {
        log.info("GET /rutas/conductor/{}", conductorId);
        return rutaService.listarPorConductor(conductorId);
    }

    @Operation(summary = "Listar rutas por vehículo")
    @ApiResponse(responseCode = "200", description = "Lista filtrada por vehículo")
    @GetMapping("/vehiculo/{vehiculoId}")
    public List<Ruta> listarPorVehiculo(@PathVariable Long vehiculoId) {
        log.info("GET /rutas/vehiculo/{}", vehiculoId);
        return rutaService.listarPorVehiculo(vehiculoId);
    }

    @Operation(summary = "Crear ruta nueva")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Ruta creada con estado PLANIFICADA"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PostMapping
    public ResponseEntity<Ruta> crear(@RequestBody @Valid RutaDTO dto) {
        log.info("POST /rutas");
        return ResponseEntity.status(HttpStatus.CREATED).body(rutaService.guardar(dto));
    }

    @Operation(summary = "Actualizar ruta existente")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Ruta actualizada"),
        @ApiResponse(responseCode = "404", description = "Ruta no encontrada")
    })
    @PutMapping("/{idRuta}")
    public ResponseEntity<Ruta> actualizar(@PathVariable Long idRuta,
                                           @RequestBody @Valid RutaDTO dto) {
        log.info("PUT /rutas/{}", idRuta);
        return ResponseEntity.ok(rutaService.actualizar(idRuta, dto));
    }

    @Operation(summary = "Eliminar ruta")
    @ApiResponses({
        @ApiResponse(responseCode = "204", description = "Ruta eliminada"),
        @ApiResponse(responseCode = "404", description = "Ruta no encontrada")
    })
    @DeleteMapping("/{idRuta}")
    public ResponseEntity<Void> eliminar(@PathVariable Long idRuta) {
        log.info("DELETE /rutas/{}", idRuta);
        rutaService.eliminar(idRuta);
        return ResponseEntity.noContent().build();
    }
}