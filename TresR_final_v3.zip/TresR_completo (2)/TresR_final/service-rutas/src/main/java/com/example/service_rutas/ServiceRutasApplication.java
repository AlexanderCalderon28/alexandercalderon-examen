package com.example.service_rutas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceRutasApplication {
    public static void main(String[] args) {
        SpringApplication.run(ServiceRutasApplication.class, args);
    }
}