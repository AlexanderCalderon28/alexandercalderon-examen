package com.example.service_rutas.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Ruta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idRuta;
    private LocalDate fecha;
    private Long conductorId;
    private Long vehiculoId;
    private String estado; // PLANIFICADA / EN_CURSO / COMPLETADA
}