package com.example.service_rutas.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDate;

@Data
public class RutaDTO {
    @NotNull(message = "La fecha es obligatoria")
    private LocalDate fecha;
    @NotNull(message = "El conductor es obligatorio")
    private Long conductorId;
    @NotNull(message = "El vehículo es obligatorio")
    private Long vehiculoId;
}