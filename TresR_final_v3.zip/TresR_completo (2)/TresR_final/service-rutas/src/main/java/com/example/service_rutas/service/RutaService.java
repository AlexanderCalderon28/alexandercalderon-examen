package com.example.service_rutas.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service_rutas.dto.RutaDTO;
import com.example.service_rutas.exception.RutaNotFoundException;
import com.example.service_rutas.model.Ruta;
import com.example.service_rutas.repository.RutaRepository;

@Service
public class RutaService {

    private static final Logger log = LoggerFactory.getLogger(RutaService.class);

    @Autowired
    private RutaRepository rutaRepository;

    public List<Ruta> listarTodas() {
        return rutaRepository.findAll();
    }

    public Optional<Ruta> buscarPorId(Long idRuta) {
        return rutaRepository.findById(idRuta);
    }

    public List<Ruta> listarPorEstado(String estado) {
        return rutaRepository.findByEstado(estado);
    }

    public List<Ruta> listarPorConductor(Long conductorId) {
        return rutaRepository.findByConductorId(conductorId);
    }

    public List<Ruta> listarPorVehiculo(Long vehiculoId) {
        return rutaRepository.findByVehiculoId(vehiculoId);
    }

    public Ruta guardar(RutaDTO dto) {
        Ruta ruta = new Ruta();
        ruta.setFecha(dto.getFecha());
        ruta.setConductorId(dto.getConductorId());
        ruta.setVehiculoId(dto.getVehiculoId());
        ruta.setEstado("PLANIFICADA"); // siempre empieza PLANIFICADA
        log.info("Creando ruta para conductor {} con vehículo {}", dto.getConductorId(), dto.getVehiculoId());
        return rutaRepository.save(ruta);
    }

    public Ruta actualizar(Long idRuta, RutaDTO dto) {
        Ruta existente = rutaRepository.findById(idRuta)
                .orElseThrow(() -> new RutaNotFoundException(idRuta));
        existente.setFecha(dto.getFecha());
        existente.setConductorId(dto.getConductorId());
        existente.setVehiculoId(dto.getVehiculoId());
        log.info("Actualizando ruta con id: {}", idRuta);
        return rutaRepository.save(existente);
    }

    public void eliminar(Long idRuta) {
        rutaRepository.findById(idRuta)
                .orElseThrow(() -> new RutaNotFoundException(idRuta));
        log.info("Eliminando ruta con id: {}", idRuta);
        rutaRepository.deleteById(idRuta);
    }
}