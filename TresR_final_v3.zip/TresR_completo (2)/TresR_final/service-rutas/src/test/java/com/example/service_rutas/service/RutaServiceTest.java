package com.example.service_rutas.service;

import com.example.service_rutas.exception.RutaNotFoundException;
import com.example.service_rutas.model.Ruta;
import com.example.service_rutas.repository.RutaRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class RutaServiceTest {

    @Mock
    private RutaRepository rutaRepository;

    @InjectMocks
    private RutaService rutaService;

    @Test
    @DisplayName("Listar todas las rutas retorna lista correcta")
    void listarTodas_retornaLista() {
        Ruta r = new Ruta();
        r.setIdRuta(1L);
        r.setEstado("PLANIFICADA");

        when(rutaRepository.findAll()).thenReturn(List.of(r));

        List<Ruta> resultado = rutaService.listarTodas();

        assertFalse(resultado.isEmpty());
        assertEquals("PLANIFICADA", resultado.get(0).getEstado());
    }

    @Test
    @DisplayName("Crear ruta asigna estado PLANIFICADA automáticamente")
    void guardar_asignaEstadoPlanificada() {
        com.example.service_rutas.dto.RutaDTO dto = new com.example.service_rutas.dto.RutaDTO();
        dto.setFecha(LocalDate.now());
        dto.setConductorId(1L);
        dto.setVehiculoId(1L);

        Ruta rutaGuardada = new Ruta();
        rutaGuardada.setEstado("PLANIFICADA");

        when(rutaRepository.save(any(Ruta.class))).thenReturn(rutaGuardada);

        Ruta resultado = rutaService.guardar(dto);

        assertEquals("PLANIFICADA", resultado.getEstado());
        verify(rutaRepository, times(1)).save(any(Ruta.class));
    }

    @Test
    @DisplayName("Listar rutas por estado retorna filtradas")
    void listarPorEstado_retornaFiltradas() {
        Ruta r = new Ruta();
        r.setEstado("EN_CURSO");

        when(rutaRepository.findByEstado("EN_CURSO")).thenReturn(List.of(r));

        List<Ruta> resultado = rutaService.listarPorEstado("EN_CURSO");

        assertEquals(1, resultado.size());
        assertEquals("EN_CURSO", resultado.get(0).getEstado());
    }

    @Test
    @DisplayName("Eliminar ruta inexistente lanza excepción")
    void eliminar_noExiste_lanzaExcepcion() {
        when(rutaRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(RutaNotFoundException.class, () -> rutaService.eliminar(99L));
    }
}
