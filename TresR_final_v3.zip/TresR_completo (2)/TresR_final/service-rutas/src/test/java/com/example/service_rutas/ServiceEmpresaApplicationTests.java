package com.example.service_rutas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceEmpresaApplicationTests {

	@Test
	void contextLoads() {
	}

}
