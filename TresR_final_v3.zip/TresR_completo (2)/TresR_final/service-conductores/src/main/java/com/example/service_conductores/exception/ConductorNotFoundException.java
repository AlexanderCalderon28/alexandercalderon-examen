package com.example.service_conductores.exception;

public class ConductorNotFoundException extends RuntimeException{

    public ConductorNotFoundException(Long idConductor) {
        super("Conductor no encontrado con id: " + idConductor); 
    }


}
