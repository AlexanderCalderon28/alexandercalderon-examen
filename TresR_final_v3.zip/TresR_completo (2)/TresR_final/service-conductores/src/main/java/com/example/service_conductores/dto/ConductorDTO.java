package com.example.service_conductores.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data 

public class ConductorDTO {

    @NotBlank(message = "El Rut es obligatorio")
    private String rutConductor;

    @NotBlank(message= "El nombre del conductor es obligatorio")
    private String nombreConductor;

    @NotBlank(message = "El apellido del conductor es obligatorio")
    private String apellidoConductor;

    @NotBlank(message = "La licencia es obligatoria")
    private String licencia;

    @NotBlank(message = "El telefono es obligatorio")
    private String telefono;
}
