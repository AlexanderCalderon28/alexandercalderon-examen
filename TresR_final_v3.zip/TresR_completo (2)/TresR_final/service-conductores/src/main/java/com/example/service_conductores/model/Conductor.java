package com.example.service_conductores.model;
import jakarta.persistence.Entity;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data 
@AllArgsConstructor
@NoArgsConstructor
public class Conductor {
    @Id 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idConductor;
    private String rutConductor;
    private String nombreConductor;
    private String apellidoConductor;
    private String licencia;
    private String telefono;
    private boolean activo;
}
