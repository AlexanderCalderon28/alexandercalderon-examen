package com.example.service_conductores.repository;

import com.example.service_conductores.model.Conductor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface ConductorRepository  extends JpaRepository<Conductor, Long>{

    Optional<Conductor> findByRutConductor(String rutConductor);

    List<Conductor> findByActivo(boolean activo);
}
