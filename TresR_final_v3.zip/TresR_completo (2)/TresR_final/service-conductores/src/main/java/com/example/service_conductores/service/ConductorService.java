package com.example.service_conductores.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.service_conductores.model.Conductor;
import com.example.service_conductores.dto.ConductorDTO;
import com.example.service_conductores.exception.ConductorNotFoundException;
import com.example.service_conductores.repository.ConductorRepository;

@Service
public class ConductorService {

    private static final Logger log = LoggerFactory.getLogger(ConductorService.class);


    @Autowired
    private ConductorRepository conductorRepository;

   
    public List<Conductor> listarTodo(){
        log.info("Listando todos los conductores: ");
        return conductorRepository.findAll();
    }

    public Optional<Conductor> buscarPorId(Long idConductor) {
        log.info("Buscando conductor con id {}", idConductor);
        return conductorRepository.findById(idConductor);
    }

    public Optional<Conductor> buscarPorRutConductor(String rutConductor){
        log.info("Buscando por rut de Conductor: ", rutConductor);
        return conductorRepository.findByRutConductor(rutConductor);
    }

    public List<Conductor> listarActivos(boolean activo){
        log.info("Buscando por activos: ");
        return conductorRepository.findByActivo(activo);
    }

    public Conductor guardar(ConductorDTO dto){
        try{
            //Regla de negocio
            if (conductorRepository.findByRutConductor(dto.getRutConductor()).isPresent()) {
                throw new IllegalArgumentException("Ya existe un conductor con ese RUT");
            }

            Conductor conductor = new Conductor();
            conductor.setRutConductor(dto.getRutConductor());
            conductor.setNombreConductor(dto.getNombreConductor());
            conductor.setApellidoConductor(dto.getApellidoConductor());
            conductor.setLicencia(dto.getLicencia());
            conductor.setTelefono(dto.getTelefono());
            conductor.setActivo(true); // todo conductor nuevo empieza activo

            log.info("Creando conductor: {}", dto.getNombreConductor());
            return conductorRepository.save(conductor);
        }//Fin try 
        catch (RuntimeException e){
            throw e;
        }
        catch (Exception e){
            log.error("Error al guardar conductor: {}", e.getMessage());
            throw new RuntimeException("No se puede guardar el conductor :(");
        }
    }

    public Conductor actualizar(Long idConductor, ConductorDTO dto) {
        Conductor existente = conductorRepository.findById(idConductor)
                .orElseThrow(() -> new ConductorNotFoundException(idConductor));

        existente.setRutConductor(dto.getRutConductor());
        existente.setNombreConductor(dto.getNombreConductor());
        existente.setApellidoConductor(dto.getApellidoConductor());
        existente.setLicencia(dto.getLicencia());
        existente.setTelefono(dto.getTelefono());

        log.info("Actualizando conductor con id {}", idConductor);
        return conductorRepository.save(existente);
    }

    public void eliminar (Long idConductor){
        try {
            if (!conductorRepository.existsById(idConductor)){
                throw new ConductorNotFoundException(idConductor);
            }
            log.info("Eliminado empresa con id: ", idConductor);
            conductorRepository.deleteById(idConductor);
        }catch (ConductorNotFoundException e){
            throw e;
        }catch (Exception e){
            log.error("Error al eliminar Conductor: {}", e.getMessage());
            throw new RuntimeException("No se puede eliminar conductor");
        }
    }
}
