package com.example.service_conductores.service;

import com.example.service_conductores.dto.ConductorDTO;
import com.example.service_conductores.exception.ConductorNotFoundException;
import com.example.service_conductores.model.Conductor;
import com.example.service_conductores.repository.ConductorRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ConductorServiceTest {

    @Mock
    private ConductorRepository conductorRepository;

    @InjectMocks
    private ConductorService conductorService;

    @Test
    @DisplayName("Listar todos los conductores retorna lista correcta")
    void listarTodo_retornaLista() {
        // Given
        Conductor c = new Conductor();
        c.setIdConductor(1L);
        c.setRutConductor("11111111-1");
        c.setNombreConductor("Juan");
        c.setActivo(true);
        when(conductorRepository.findAll()).thenReturn(List.of(c));

        // When
        List<Conductor> resultado = conductorService.listarTodo();

        // Then
        assertFalse(resultado.isEmpty());
        assertEquals("Juan", resultado.get(0).getNombreConductor());
        verify(conductorRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Buscar conductor por id inexistente retorna vacío")
    void buscarPorId_noExiste_retornaVacio() {
        // Given
        when(conductorRepository.findById(99L)).thenReturn(Optional.empty());

        // When
        Optional<Conductor> resultado = conductorService.buscarPorId(99L);

        // Then
        assertTrue(resultado.isEmpty());
    }

    @Test
    @DisplayName("Listar conductores activos retorna solo los activos")
    void listarActivos_retornaSoloActivos() {
        // Given
        Conductor c = new Conductor();
        c.setActivo(true);
        when(conductorRepository.findByActivo(true)).thenReturn(List.of(c));

        // When
        List<Conductor> resultado = conductorService.listarActivos(true);

        // Then
        assertEquals(1, resultado.size());
        assertTrue(resultado.get(0).isActivo());
    }

    @Test
    @DisplayName("Crear conductor con RUT duplicado lanza excepción")
    void guardar_rutDuplicado_lanzaExcepcion() {
        // Given
        Conductor existente = new Conductor();
        existente.setRutConductor("11111111-1");
        when(conductorRepository.findByRutConductor("11111111-1")).thenReturn(Optional.of(existente));

        ConductorDTO dto = new ConductorDTO();
        dto.setRutConductor("11111111-1");

        // When / Then
        assertThrows(IllegalArgumentException.class, () -> conductorService.guardar(dto));
        verify(conductorRepository, never()).save(any());
    }

    @Test
    @DisplayName("Crear conductor válido se guarda como activo por defecto")
    void guardar_conductorValido_seGuardaActivo() {
        // Given
        ConductorDTO dto = new ConductorDTO();
        dto.setRutConductor("22222222-2");
        dto.setNombreConductor("Pedro");
        dto.setApellidoConductor("Soto");
        dto.setLicencia("A1");
        dto.setTelefono("987654321");

        when(conductorRepository.findByRutConductor("22222222-2")).thenReturn(Optional.empty());
        when(conductorRepository.save(any(Conductor.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // When
        Conductor resultado = conductorService.guardar(dto);

        // Then
        assertTrue(resultado.isActivo());
        assertEquals("Pedro", resultado.getNombreConductor());
        verify(conductorRepository, times(1)).save(any(Conductor.class));
    }

    @Test
    @DisplayName("Actualizar conductor inexistente lanza ConductorNotFoundException")
    void actualizar_noExiste_lanzaExcepcion() {
        // Given
        when(conductorRepository.findById(99L)).thenReturn(Optional.empty());
        ConductorDTO dto = new ConductorDTO();

        // When / Then
        assertThrows(ConductorNotFoundException.class, () -> conductorService.actualizar(99L, dto));
    }

    @Test
    @DisplayName("Eliminar conductor inexistente lanza ConductorNotFoundException")
    void eliminar_noExiste_lanzaExcepcion() {
        // Given
        when(conductorRepository.existsById(99L)).thenReturn(false);

        // When / Then
        assertThrows(ConductorNotFoundException.class, () -> conductorService.eliminar(99L));
        verify(conductorRepository, never()).deleteById(any());
    }
}
