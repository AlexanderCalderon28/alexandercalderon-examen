package com.example.service_conductores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceConductoresApplicationTests {

	@Test
	void contextLoads() {
	}

}
