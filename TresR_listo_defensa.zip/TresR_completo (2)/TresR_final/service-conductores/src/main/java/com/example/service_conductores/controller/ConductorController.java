package com.example.service_conductores.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service_conductores.dto.ConductorDTO;
import com.example.service_conductores.model.Conductor;
import com.example.service_conductores.service.ConductorService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/conductores")
public class ConductorController {

    private static final Logger log = LoggerFactory.getLogger(ConductorController.class);

    @Autowired
    private ConductorService conductorService;

    @Operation(summary = "Listar conductores", description = "Retorna todos los conductores registrados")
    @GetMapping
    public List<Conductor> listarTodo(){
        log.info("GET/conductores");
        return conductorService.listarTodo();
    }

    @Operation(summary = "Obtener conductor por ID", description = "Busca un conductor específico según su ID")
    @GetMapping("/{idConductor}")
    public ResponseEntity<Conductor> obtenerId (@PathVariable Long idConductor){
        log.info("GET /conductores/{}", idConductor);
        return conductorService.buscarPorId(idConductor).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Listar conductores activos", description = "Retorna solo los conductores marcados como activos")
    @GetMapping("/activos")
    public List<Conductor> listarActivos(){
        log.info("GET /conductores/activo");
        return conductorService.listarActivos(true);
    }

    @Operation(summary = "Buscar conductor por RUT", description = "Busca un conductor según su RUT")
    @GetMapping("/rut/{rutConductor}")
    public ResponseEntity<Conductor> buscarPorRut(@PathVariable String rutConductor){
        log.info("GET /conductores/rut/{rut} ", rutConductor);
        return conductorService.buscarPorRutConductor(rutConductor).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Crear conductor", description = "Registra un nuevo conductor en el sistema")
    @PostMapping
    public ResponseEntity<Conductor> crear(@RequestBody @Valid ConductorDTO dto){
        log.info("POST /conductores/{}", dto.getRutConductor());
        return ResponseEntity.status(HttpStatus.CREATED).body(conductorService.guardar(dto));
    }

    @Operation(summary = "Actualizar conductor", description = "Modifica los datos de un conductor existente")
    @PutMapping("/{idConductor}")
    public ResponseEntity<Conductor> actualizar(@PathVariable Long idConductor, @RequestBody @Valid ConductorDTO dto){
        log.info("PUT /conductores/{}", idConductor); 
        return ResponseEntity.ok(conductorService.actualizar(idConductor, dto));
    }
    @Operation(summary = "Eliminar conductor", description = "Elimina un conductor por su ID")
    @DeleteMapping("/{idConductor}")
    public ResponseEntity<Void> eliminar (@PathVariable Long idConductor){
        log.info("Eliminado conductor con id: {}", idConductor);
        conductorService.eliminar(idConductor);
        return ResponseEntity.noContent().build();
    }

}
