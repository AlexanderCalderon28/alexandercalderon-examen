package com.example.service_conductores.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("TresR - API Conductores")
                        .version("1.0")
                        .description("Gestión de conductores de la flota TresR"))
                .servers(List.of(
                        new Server().url("http://localhost:8086").description("Servidor local")
                ));
    }
}
