package com.example.service_materiales.controller;

import com.example.service_materiales.dto.MaterialDTO;
import com.example.service_materiales.model.Material;
import com.example.service_materiales.service.MaterialService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Tag(name = "Materiales", description = "Gestión de materiales reciclables")
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/materiales")
public class MaterialController {

    private static final Logger log = LoggerFactory.getLogger(MaterialController.class);

    @Autowired
    private MaterialService materialService;

    @Operation(summary = "Listar todos los materiales")
    @ApiResponse(responseCode = "200", description = "Lista obtenida correctamente")
    @GetMapping
    public List<Material> listar() {
        log.info("GET /materiales");
        return materialService.listarTodos();
    }

    @Operation(summary = "Obtener material por ID")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Material encontrado"),
        @ApiResponse(responseCode = "404", description = "Material no encontrado",
        content = @Content(schema = @Schema(implementation = com.example.service_materiales.config.ErrorResponse.class)))
    })
    @GetMapping("/{idMaterial}")
    public ResponseEntity<Material> obtener(@PathVariable Long idMaterial) {
        log.info("GET /materiales/{}", idMaterial);
        return materialService.buscarPorId(idMaterial)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Listar materiales activos")
    @ApiResponse(responseCode = "200", description = "Lista de materiales activos")
    @GetMapping("/activos")
    public List<Material> listarActivos() {
        log.info("GET /materiales/activos");
        return materialService.listarActivos();
    }

    @Operation(summary = "Crear material nuevo")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Material creado"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PostMapping
    public ResponseEntity<Material> crear(@RequestBody @Valid MaterialDTO dto) {
        log.info("POST /materiales");
        return ResponseEntity.ok(materialService.guardar(dto));
    }

    @Operation(summary = "Actualizar material existente")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Material actualizado"),
        @ApiResponse(responseCode = "404", description = "Material no encontrado",
        content = @Content(schema = @Schema(implementation = com.example.service_materiales.config.ErrorResponse.class)))
    })
    @PutMapping("/{idMaterial}")
    public ResponseEntity<Material> actualizar(@PathVariable Long idMaterial,
                                               @RequestBody @Valid MaterialDTO dto) {
        log.info("PUT /materiales/{}", idMaterial);
        return ResponseEntity.ok(materialService.actualizar(idMaterial, dto));
    }

    @Operation(summary = "Eliminar material")
    @ApiResponses({
        @ApiResponse(responseCode = "204", description = "Material eliminado"),
        @ApiResponse(responseCode = "404", description = "Material no encontrado",
        content = @Content(schema = @Schema(implementation = com.example.service_materiales.config.ErrorResponse.class)))
    })
    @DeleteMapping("/{idMaterial}")
    public ResponseEntity<Void> eliminar(@PathVariable Long idMaterial) {
        log.info("DELETE /materiales/{}", idMaterial);
        materialService.eliminar(idMaterial);
        return ResponseEntity.noContent().build();
    }
}
