package com.example.service_materiales.controller;

import java.util.List;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service_materiales.model.CategoriaMaterial;
import com.example.service_materiales.repository.CategoriaMaterialRepository;

import io.swagger.v3.oas.annotations.Operation;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/materiales/categorias")
public class CategoriaMaterialController {

    @Autowired
    private CategoriaMaterialRepository repository;

    @Operation(summary = "Listar categorías de material", description = "Retorna el catálogo de categorías de materiales reciclables")
    @GetMapping
    public ResponseEntity<List<CategoriaMaterial>> listar()  {
        return ResponseEntity.ok(repository.findAll());
    }

    @Operation(summary = "Crear categoría de material", description = "Registra una nueva categoría en el catálogo")
    @PostMapping
    public ResponseEntity<CategoriaMaterial> crear(@Valid @RequestBody CategoriaMaterial categoria) {
        CategoriaMaterial guardada = repository.save(categoria);
        return ResponseEntity.ok(guardada);
    }
}
