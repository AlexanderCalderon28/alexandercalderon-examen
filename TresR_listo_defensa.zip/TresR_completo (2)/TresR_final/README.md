# TresR — Sistema de Gestión de Reciclaje Industrial

> Proyecto Semestral — Arquitectura de Microservicios  
> Asignatura: Desarrollo Full Stack I (DSY1103) · Sección 001D · DuocUC

---

## Integrantes

| Nombre | Rol |
|--------|-----|
| Alexander Calderón Muñoz | Desarrollador Backend |
| Valentina Alejandra Cordero Araneda | Desarrolladora Backend |
| Valeria Alexandra Ortega Marianjel | Desarrolladora Backend |

---

## Descripción del Proyecto

**TresR** es una empresa de gestión de residuos industriales que presta servicios de retiro, transporte y reciclaje de materiales para empresas clientes del sector industrial.

El sistema gestiona el ciclo completo del negocio:

1. Una **empresa cliente** se registra con su tipo de empresa
2. Se firma un **contrato** indicando el material a retirar y la frecuencia
3. Se asignan **conductores** y **vehículos** a **rutas** de recolección
4. Cada retiro físico se registra como una **recolección** (PENDIENTE → REALIZADA)
5. Si ocurre un problema se registra como una **incidencia** (ABIERTA → RESUELTA)
6. El sistema genera **reportes** y **estadísticas** consolidadas en tiempo real

---

## Microservicios Implementados

| # | Microservicio | Puerto | Base de Datos |
|---|---------------|--------|---------------|
| 1 | service-empresa | 8081 | db_tresr_empresas |
| 2 | service-contratos | 8082 | db_tresr_contratos |
| 3 | service-recolecciones | 8083 | db_tresr_recolecciones |
| 4 | service-materiales | 8084 | db_tresr_materiales |
| 5 | service-reportes | 8085 | db_tresr_reportes |
| 6 | service-conductores | 8086 | db_tresr_conductores |
| 7 | service-vehiculos | 8087 | db_tresr_vehiculos |
| 8 | service-rutas | 8088 | db_tresr_rutas |
| 9 | service-incidencia | 8089 | db_tresr_incidencias |
| 10 | service-estadisticas | 8090 | — (consulta otros MS) |
| — | gateway | 9091 | — |

---

## ▶️ Ejecución de Pruebas Unitarias

> **Para la defensa:** ejecutar estos comandos en una terminal desde la raíz del proyecto.

Cada microservicio tiene su propio `mvnw.cmd` (Windows) / `mvnw` (Mac/Linux).  
Las pruebas usan **JUnit 5 + Mockito** y simulan el repositorio con mocks — **no necesitan MySQL activo**.

### Comandos por microservicio (Windows)

```bash
# Empresas (8 tests)
cd TresR_final
cd service-empresa\service-empresa
.\mvnw.cmd test

# Contratos (8 tests)
cd TresR_final
cd service-contratos\service-contratos
.\mvnw.cmd test

# Recolecciones (7 tests)
cd TresR_final
cd service-recolecciones\service-recolecciones
.\mvnw.cmd test

# Materiales (4 tests)
cd TresR_final
cd service-materiales\service-materiales
.\mvnw.cmd test

# Reportes (2 tests)
cd TresR_final
cd service-reportes\service-reportes
.\mvnw.cmd test

# Conductores (7 tests)
cd TresR_final
cd service-conductores
.\mvnw.cmd test

# Vehículos (4 tests)
cd TresR_final
cd service-vehiculos
.\mvnw.cmd test

# Rutas (4 tests)
cd TresR_final
cd service-rutas
.\mvnw.cmd test

# Incidencias (4 tests)
cd TresR_final
cd service-incidencia
.\mvnw.cmd test

# Estadísticas (2 tests)
cd TresR_final
cd service-estadisticas
.\mvnw.cmd test
```

### Comandos por microservicio (Mac / Linux)

```bash
cd TresR_final/service-conductores
./mvnw test
```

### ✅ Qué valida cada test (para la defensa)

#### service-empresa — `EmpresaServiceTest` (8 tests)
| Test | Qué valida |
|------|-----------|
| `listarTodo_retornaLista` | Listar todas las empresas retorna lista correcta |
| `buscarPorId_noExiste_retornaVacio` | Buscar empresa por id inexistente retorna vacío |
| `guardar_sinTipoEmpresa_noConsultaTipo` | Guardar empresa sin tipoEmpresaId no consulta TipoEmpresaRepository |
| `guardar_tipoEmpresaInexistente_lanzaExcepcion` | Guardar empresa con tipoEmpresaId inexistente lanza excepción |
| `guardar_conTipoEmpresaValido_asociaTipo` | Guardar empresa con tipoEmpresaId válido asocia el tipo correctamente |

#### service-contratos — `ContratoServiceTest` (8 tests)
| Test | Qué valida |
|------|-----------|
| `listarTodo_retornaLista` | Listar todos los contratos retorna lista correcta |
| `guardar_fechaInvalida_lanzaExcepcion` | ⭐ **Regla de negocio:** fechaFin anterior a fechaInicio lanza excepción |
| `guardar_contratoValido_consultaEmpresaYQuedaActivo` | ⭐ **Regla de negocio:** contrato válido consulta empresa vía WebClient y queda ACTIVO |
| `buscarPorId_noExiste_retornaVacio` | Buscar por id inexistente retorna vacío |

#### service-recolecciones — `RecoleccionServiceTest` (7 tests)
| Test | Qué valida |
|------|-----------|
| `listarTodo_retornaLista` | Listar todas las recolecciones retorna lista correcta |
| `guardar_estadoSiemprePendiente` | ⭐ **Regla de negocio:** estado siempre queda PENDIENTE al crear |
| `listarPorContrato_retornaRecoleccionesDelContrato` | Filtrar por contrato retorna las correctas |
| `buscarPorId_noExiste_retornaVacio` | Buscar por id inexistente retorna Optional vacío |
| `actualizar_noExiste_lanzaExcepcion` | Actualizar recolección inexistente lanza excepción |

#### service-materiales — `MaterialServiceTest` (4 tests)
| Test | Qué valida |
|------|-----------|
| `listarTodos_retornaLista` | Listar todos los materiales retorna lista correcta |
| `buscarPorId_noExiste_retornaVacio` | Buscar material por id inexistente retorna vacío |
| `listarActivos_retornaSoloActivos` | Listar materiales activos retorna solo activos |
| `eliminar_noExiste_lanzaExcepcion` | Eliminar material inexistente lanza excepción |

#### service-conductores — `ConductorServiceTest` (7 tests)
| Test | Qué valida |
|------|-----------|
| `listarTodo_retornaLista` | Listar todos los conductores retorna lista correcta |
| `buscarPorId_noExiste_retornaVacio` | Buscar conductor por id inexistente retorna vacío |
| `listarActivos_retornaSoloActivos` | Listar conductores activos retorna solo los activos |
| `guardar_rutDuplicado_lanzaExcepcion` | ⭐ **Regla de negocio:** RUT duplicado lanza excepción |
| `guardar_conductorValido_seGuardaActivo` | ⭐ **Regla de negocio:** conductor nuevo queda activo por defecto |

#### service-vehiculos — `VehiculoServiceTest` (4 tests)
| Test | Qué valida |
|------|-----------|
| `listarTodo_retornaLista` | Listar todos los vehículos retorna lista correcta |
| `buscarPorId_noExiste_retornaVacio` | Buscar vehículo por id inexistente retorna vacío |
| `guardar_patenteDuplicada_lanzaExcepcion` | ⭐ **Regla de negocio:** patente duplicada lanza excepción |
| `eliminar_noExiste_lanzaExcepcion` | Eliminar vehículo inexistente lanza excepción |

#### service-rutas — `RutaServiceTest` (4 tests)
| Test | Qué valida |
|------|-----------|
| `listarTodas_retornaLista` | Listar todas las rutas retorna lista correcta |
| `guardar_asignaEstadoPlanificada` | ⭐ **Regla de negocio:** estado siempre queda PLANIFICADA al crear |
| `listarPorEstado_retornaFiltradas` | Filtrar rutas por estado retorna las correctas |
| `eliminar_noExiste_lanzaExcepcion` | Eliminar ruta inexistente lanza excepción |

#### service-incidencia — `IncidenciaServiceTest` (4 tests)
| Test | Qué valida |
|------|-----------|
| `listarTodas_retornaLista` | Listar todas las incidencias retorna lista correcta |
| `guardar_asignaEstadoAbierta` | ⭐ **Regla de negocio:** estado siempre queda ABIERTA al crear |
| `listarPorEstado_retornaFiltradas` | Filtrar por estado RESUELTA retorna las correctas |
| `eliminar_noExiste_lanzaExcepcion` | Eliminar incidencia inexistente lanza excepción |

#### service-reportes — `ReporteServiceTest` (2 tests)
| Test | Qué valida |
|------|-----------|
| `obtenerEmpresas_retornaLista` | Comunicación WebClient con service-empresa retorna resultado |
| `obtenerPendientes_retornaLista` | Comunicación WebClient con service-recolecciones retorna resultado |

#### service-estadisticas — `EstadisticaServiceTest` (2 tests)
| Test | Qué valida |
|------|-----------|
| `totalRecolecciones_retornaResultado` | Comunicación WebClient retorna resultado no nulo |
| `materialesActivos_retornaResultado` | Comunicación WebClient retorna resultado no nulo |

### ¿Qué ver cuando el test pasa?

Al ejecutar `.\mvnw.cmd test` y todos los tests pasan, verás en la terminal:

```
[INFO] Tests run: 7, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
```

---

## Documentación Swagger / OpenAPI

Una vez levantado cada microservicio, abrir en el navegador:

```
http://localhost:8081/swagger-ui/index.html   →  Empresas
http://localhost:8082/swagger-ui/index.html   →  Contratos
http://localhost:8083/swagger-ui/index.html   →  Recolecciones
http://localhost:8084/swagger-ui/index.html   →  Materiales
http://localhost:8085/swagger-ui/index.html   →  Reportes
http://localhost:8086/swagger-ui/index.html   →  Conductores
http://localhost:8087/swagger-ui/index.html   →  Vehículos
http://localhost:8088/swagger-ui/index.html   →  Rutas
http://localhost:8089/swagger-ui/index.html   →  Incidencias
http://localhost:8090/swagger-ui/index.html   →  Estadísticas
```

---

## Rutas del API Gateway — `http://localhost:9091`

```
/empresas/**       → service-empresa      (8081)
/contratos/**      → service-contratos     (8082)
/recolecciones/**  → service-recolecciones (8083)
/materiales/**     → service-materiales    (8084)
/reportes/**       → service-reportes      (8085)
/conductores/**    → service-conductores   (8086)
/vehiculos/**      → service-vehiculos     (8087)
/rutas/**          → service-rutas         (8088)
/incidencias/**    → service-incidencia    (8089)
/estadisticas/**   → service-estadisticas  (8090)
```

---

## Cómo Levantar el Proyecto

### Requisitos
- Java 21, Maven 3.x, MySQL 8 (XAMPP), Postman

### Configurar contraseña MySQL

En el `application.yml` de cada servicio (sección `dev`):
```yaml
spring:
  datasource:
    password: TU_PASSWORD
```

### Orden de arranque (desde cada carpeta del servicio)

```
1.  service-materiales/service-materiales   → .\mvnw.cmd spring-boot:run
2.  service-empresa/service-empresa         → .\mvnw.cmd spring-boot:run
3.  service-conductores                     → .\mvnw.cmd spring-boot:run
4.  service-vehiculos                       → .\mvnw.cmd spring-boot:run
5.  service-contratos/service-contratos     → .\mvnw.cmd spring-boot:run
6.  service-rutas                           → .\mvnw.cmd spring-boot:run
7.  service-recolecciones/service-recolecciones → .\mvnw.cmd spring-boot:run
8.  service-incidencia                      → .\mvnw.cmd spring-boot:run
9.  service-reportes/service-reportes       → .\mvnw.cmd spring-boot:run
10. service-estadisticas                    → .\mvnw.cmd spring-boot:run
11. gateway/gateway                         → .\mvnw.cmd spring-boot:run
```

---

## Tecnologías

| Tecnología | Versión |
|------------|---------|
| Java | 21 |
| Spring Boot | 3.4.5 |
| Spring Cloud Gateway | 2024.0.1 |
| Spring Data JPA + Hibernate | Incluida |
| Spring WebFlux (WebClient) | Incluida |
| springdoc-openapi | 2.3.0 |
| JUnit 5 + Mockito | Incluida |
| Bean Validation (JSR 380) | Incluida |
| MySQL | 8.x |
| Lombok | Incluida |

---

## Nombre del Repositorio

`TresR-calderon-cordero-ortega-001d`
