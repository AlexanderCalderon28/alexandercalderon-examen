package com.example.service_vehiculos.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.service_vehiculos.dto.VehiculoDTO;
import com.example.service_vehiculos.model.Vehiculo;
import com.example.service_vehiculos.service.VehiculoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@Tag(name = "Vehículos", description = "Gestión de vehículos de TresR")
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/vehiculos")
public class VehiculosController {

    private static final Logger log = LoggerFactory.getLogger(VehiculosController.class);

    @Autowired
    private VehiculoService vehiculoService;

    @Operation(summary = "Listar todos los vehículos")
    @ApiResponse(responseCode = "200", description = "Lista obtenida correctamente")
    @GetMapping
    public List<Vehiculo> listarTodo() {
        log.info("GET /vehiculos");
        return vehiculoService.listarTodo();
    }

    @Operation(summary = "Obtener vehículo por ID")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Vehículo encontrado"),
        @ApiResponse(responseCode = "404", description = "Vehículo no encontrado",
        content = @Content(schema = @Schema(implementation = com.example.service_vehiculos.config.ErrorResponse.class)))
    })
    @GetMapping("/{idVehiculo}")
    public ResponseEntity<Vehiculo> obtenerPorId(@PathVariable Long idVehiculo) {
        log.info("GET /vehiculos/{}", idVehiculo);
        return vehiculoService.buscarPorId(idVehiculo)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Listar vehículos activos")
    @ApiResponse(responseCode = "200", description = "Lista de vehículos activos")
    @GetMapping("/activos")
    public List<Vehiculo> listarActivos() {
        log.info("GET /vehiculos/activos");
        return vehiculoService.listarActivos(true);
    }

    @Operation(summary = "Crear vehículo nuevo")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Vehículo creado"),
        @ApiResponse(responseCode = "400", description = "Patente duplicada o datos inválidos")
    })
    @PostMapping
    public ResponseEntity<Vehiculo> crear(@RequestBody @Valid VehiculoDTO dto) {
        log.info("POST /vehiculos - patente: {}", dto.getPatente());
        return ResponseEntity.status(HttpStatus.CREATED).body(vehiculoService.guardar(dto));
    }

    @Operation(summary = "Actualizar vehículo existente")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Vehículo actualizado"),
        @ApiResponse(responseCode = "404", description = "Vehículo no encontrado",
        content = @Content(schema = @Schema(implementation = com.example.service_vehiculos.config.ErrorResponse.class)))
    })
    @PutMapping("/{idVehiculo}")
    public ResponseEntity<Vehiculo> actualizar(@PathVariable Long idVehiculo,
                                               @RequestBody @Valid VehiculoDTO dto) {
        log.info("PUT /vehiculos/{}", idVehiculo);
        return ResponseEntity.ok(vehiculoService.actualizar(idVehiculo, dto));
    }

    @Operation(summary = "Eliminar vehículo")
    @ApiResponses({
        @ApiResponse(responseCode = "204", description = "Vehículo eliminado"),
        @ApiResponse(responseCode = "404", description = "Vehículo no encontrado",
        content = @Content(schema = @Schema(implementation = com.example.service_vehiculos.config.ErrorResponse.class)))
    })
    @DeleteMapping("/{idVehiculo}")
    public ResponseEntity<Void> eliminar(@PathVariable Long idVehiculo) {
        log.info("DELETE /vehiculos/{}", idVehiculo);
        vehiculoService.eliminar(idVehiculo);
        return ResponseEntity.noContent().build();
    }
}