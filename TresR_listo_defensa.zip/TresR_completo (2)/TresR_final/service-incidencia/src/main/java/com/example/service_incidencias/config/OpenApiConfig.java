package com.example.service_incidencias.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("TresR - API Incidencias")
                        .version("1.0")
                        .description("Gestión de incidencias operativas de TresR"))
                .servers(List.of(
                        new Server().url("http://localhost:8089").description("Servidor local")
                ));
    }
}
