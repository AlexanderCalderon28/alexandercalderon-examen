package com.example.service_reportes.controller;

import com.example.service_reportes.service.ReporteService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Reportes", description = "Reportes consolidados del sistema TresR — consume datos de los demás microservicios vía WebClient")
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/reportes")
public class ReporteController {

    private static final Logger log = LoggerFactory.getLogger(ReporteController.class);

    @Autowired
    private ReporteService reporteService;

    @Operation(summary = "Reporte de empresas", description = "Consolida información de empresas obtenida desde service-empresa")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista de empresas obtenida correctamente"),
        @ApiResponse(responseCode = "503", description = "service-empresa no disponible")
    })
    @GetMapping("/empresas")
    public ResponseEntity<Object> empresas() {
        log.info("GET /reportes/empresas");
        return ResponseEntity.ok(reporteService.obtenerEmpresas());
    }

    @Operation(summary = "Reporte de contratos", description = "Consolida información de contratos obtenida desde service-contratos")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista de contratos obtenida correctamente"),
        @ApiResponse(responseCode = "503", description = "service-contratos no disponible")
    })
    @GetMapping("/contratos")
    public ResponseEntity<Object> contratos() {
        log.info("GET /reportes/contratos");
        return ResponseEntity.ok(reporteService.obtenerContratos());
    }

    @Operation(summary = "Reporte de recolecciones", description = "Consolida información de recolecciones obtenida desde service-recolecciones")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista de recolecciones obtenida correctamente"),
        @ApiResponse(responseCode = "503", description = "service-recolecciones no disponible")
    })
    @GetMapping("/recolecciones")
    public ResponseEntity<Object> recolecciones() {
        log.info("GET /reportes/recolecciones");
        return ResponseEntity.ok(reporteService.obtenerRecolecciones());
    }

    @Operation(summary = "Reporte de materiales", description = "Consolida información de materiales obtenida desde service-materiales")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista de materiales obtenida correctamente"),
        @ApiResponse(responseCode = "503", description = "service-materiales no disponible")
    })
    @GetMapping("/materiales")
    public ResponseEntity<Object> materiales() {
        log.info("GET /reportes/materiales");
        return ResponseEntity.ok(reporteService.obtenerMateriales());
    }

    @Operation(summary = "Reporte de recolecciones pendientes", description = "Consolida las recolecciones con estado PENDIENTE obtenidas desde service-recolecciones")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista de pendientes obtenida correctamente"),
        @ApiResponse(responseCode = "503", description = "service-recolecciones no disponible")
    })
    @GetMapping("/pendientes")
    public ResponseEntity<Object> pendientes() {
        log.info("GET /reportes/pendientes");
        return ResponseEntity.ok(reporteService.obtenerPendientes());
    }
}
