package com.example.service_contratos.controller;

import java.util.List;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.service_contratos.dto.ContratoDTO;
import com.example.service_contratos.model.Contrato;
import com.example.service_contratos.service.ContratoService;

@Tag(name = "Contratos", description = "Gestión de contratos de retiro de materiales de TresR")
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/contratos")
public class ContratoController {

    private static final Logger log = LoggerFactory.getLogger(ContratoController.class);

    @Autowired
    private ContratoService contratoService;

    @Operation(summary = "Listar todos los contratos", description = "Retorna todos los contratos registrados en el sistema")
    @ApiResponse(responseCode = "200", description = "Lista obtenida correctamente")
    @GetMapping
    public List<Contrato> listar() {
        log.info("GET /contratos");
        return contratoService.listarTodo();
    }

    @Operation(summary = "Listar contratos por empresa", description = "Retorna todos los contratos asociados a una empresa específica")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista filtrada por empresa"),
        @ApiResponse(responseCode = "404", description = "Empresa no encontrada",
        content = @Content(schema = @Schema(implementation = com.example.service_contratos.config.ErrorResponse.class)))
    })
    @GetMapping("/empresa/{empresaId}")
    public List<Contrato> listarPorEmpresa(@PathVariable Long empresaId) {
        log.info("GET /contratos/empresa/{}", empresaId);
        return contratoService.listarPorEmpresa(empresaId);
    }

    @Operation(summary = "Obtener contrato por ID", description = "Busca un contrato específico según su ID")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Contrato encontrado"),
        @ApiResponse(responseCode = "404", description = "Contrato no encontrado",
        content = @Content(schema = @Schema(implementation = com.example.service_contratos.config.ErrorResponse.class)))
    })
    @GetMapping("/{idContrato}")
    public ResponseEntity<Contrato> obtener(@PathVariable Long idContrato) {
        log.info("GET /contratos/{}", idContrato);
        return contratoService.buscarPorId(idContrato)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Crear contrato", description = "Registra un nuevo contrato de servicio para una empresa. Valida que la empresa exista antes de crear.")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Contrato creado con estado ACTIVO"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos o fechas incorrectas"),
        @ApiResponse(responseCode = "404", description = "Empresa no encontrada en service-empresa",
        content = @Content(schema = @Schema(implementation = com.example.service_contratos.config.ErrorResponse.class)))
    })
    @PostMapping
    public ResponseEntity<Contrato> crear(@RequestBody @Valid ContratoDTO dto) {
        log.info("POST /contratos - empresa id {}", dto.getEmpresaId());
        return ResponseEntity.status(HttpStatus.CREATED).body(contratoService.guardar(dto));
    }

    @Operation(summary = "Actualizar contrato", description = "Modifica los datos de un contrato existente")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Contrato actualizado correctamente"),
        @ApiResponse(responseCode = "404", description = "Contrato no encontrado",
        content = @Content(schema = @Schema(implementation = com.example.service_contratos.config.ErrorResponse.class))),
        @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PutMapping("/{idContrato}")
    public ResponseEntity<Contrato> actualizar(@PathVariable Long idContrato,
                                               @RequestBody @Valid ContratoDTO dto) {
        log.info("PUT /contratos/{}", idContrato);
        return ResponseEntity.ok(contratoService.actualizar(idContrato, dto));
    }

    @Operation(summary = "Eliminar contrato", description = "Elimina un contrato por su ID")
    @ApiResponses({
        @ApiResponse(responseCode = "204", description = "Contrato eliminado correctamente"),
        @ApiResponse(responseCode = "404", description = "Contrato no encontrado",
        content = @Content(schema = @Schema(implementation = com.example.service_contratos.config.ErrorResponse.class)))
    })
    @DeleteMapping("/{idContrato}")
    public ResponseEntity<Void> eliminar(@PathVariable Long idContrato) {
        log.info("DELETE /contratos/{}", idContrato);
        contratoService.eliminar(idContrato);
        return ResponseEntity.noContent().build();
    }
}
