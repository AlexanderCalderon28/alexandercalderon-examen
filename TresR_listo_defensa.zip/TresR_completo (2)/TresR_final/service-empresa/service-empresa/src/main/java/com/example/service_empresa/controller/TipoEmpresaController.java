package com.example.service_empresa.controller;

import java.util.List;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.service_empresa.model.TipoEmpresa;
import com.example.service_empresa.repository.TipoEmpresaRepository;

@Tag(name = "Tipos de Empresa", description = "Catálogo de tipos de empresa del sistema TresR")
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/empresas/tipos")
public class TipoEmpresaController {

    @Autowired
    private TipoEmpresaRepository repository;

    @Operation(summary = "Listar tipos de empresa", description = "Retorna el catálogo completo de tipos de empresa disponibles")
    @ApiResponse(responseCode = "200", description = "Catálogo obtenido correctamente")
    @GetMapping
    public ResponseEntity<List<TipoEmpresa>> listar() {
        return ResponseEntity.ok(repository.findAll());
    }

    @Operation(summary = "Crear tipo de empresa", description = "Registra un nuevo tipo de empresa en el catálogo")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Tipo de empresa creado correctamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PostMapping
    public ResponseEntity<TipoEmpresa> crear(@Valid @RequestBody TipoEmpresa tipo) {
        TipoEmpresa guardado = repository.save(tipo);
        return ResponseEntity.status(HttpStatus.CREATED).body(guardado);
    }
}
