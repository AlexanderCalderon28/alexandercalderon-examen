package com.example.service_empresa.controller;

import java.util.List;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.service_empresa.dto.EmpresaDTO;
import com.example.service_empresa.model.Empresa;
import com.example.service_empresa.service.EmpresaService;

@Tag(name = "Empresas", description = "Gestión de empresas clientes de TresR")
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/empresas")
public class EmpresaController {

    private static final Logger log = LoggerFactory.getLogger(EmpresaController.class);

    @Autowired
    private EmpresaService empresaService;

    @Operation(summary = "Listar todas las empresas", description = "Retorna todas las empresas registradas en el sistema")
    @ApiResponse(responseCode = "200", description = "Lista obtenida correctamente")
    @GetMapping
    public List<Empresa> listar() {
        log.info("GET /empresas");
        return empresaService.listarTodo();
    }

    @Operation(summary = "Obtener empresa por ID", description = "Busca una empresa específica según su ID")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Empresa encontrada"),
        @ApiResponse(responseCode = "404", description = "Empresa no encontrada",
        content = @Content(schema = @Schema(implementation = com.example.service_empresa.config.ErrorResponse.class)))
    })
    @GetMapping("/{idEmpresa}")
    public ResponseEntity<Empresa> buscarPorId(@PathVariable Long idEmpresa) {
        log.info("GET /empresas/{}", idEmpresa);
        return empresaService.buscarPorId(idEmpresa)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Crear empresa", description = "Registra una nueva empresa cliente en el sistema")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Empresa creada correctamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos o RUT duplicado")
    })
    @PostMapping
    public ResponseEntity<Empresa> guardar(@RequestBody @Valid EmpresaDTO dto) {
        log.info("POST /empresas");
        return ResponseEntity.status(HttpStatus.CREATED).body(empresaService.guardar(dto));
    }

    @Operation(summary = "Actualizar empresa", description = "Modifica los datos de una empresa existente")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Empresa actualizada correctamente"),
        @ApiResponse(responseCode = "404", description = "Empresa no encontrada",
        content = @Content(schema = @Schema(implementation = com.example.service_empresa.config.ErrorResponse.class))),
        @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PutMapping("/{idEmpresa}")
    public ResponseEntity<Empresa> actualizar(@PathVariable Long idEmpresa,
                                              @RequestBody @Valid EmpresaDTO dto) {
        log.info("PUT /empresas/{}", idEmpresa);
        return ResponseEntity.ok(empresaService.actualizar(idEmpresa, dto));
    }

    @Operation(summary = "Eliminar empresa", description = "Elimina una empresa por su ID")
    @ApiResponses({
        @ApiResponse(responseCode = "204", description = "Empresa eliminada correctamente"),
        @ApiResponse(responseCode = "404", description = "Empresa no encontrada",
        content = @Content(schema = @Schema(implementation = com.example.service_empresa.config.ErrorResponse.class)))
    })
    @DeleteMapping("/{idEmpresa}")
    public ResponseEntity<Void> eliminar(@PathVariable Long idEmpresa) {
        log.info("DELETE /empresas/{}", idEmpresa);
        empresaService.eliminar(idEmpresa);
        return ResponseEntity.noContent().build();
    }
}
